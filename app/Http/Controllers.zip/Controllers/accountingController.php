<?php

namespace App\Http\Controllers;

use App\Models\Qayd;
use App\Models\Qayditem;
use Carbon\Carbon;
use Illuminate\Http\Request;

class accountingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    

    public function createQuid($account_from , $account_to , $date ,$type, $notes ){
        /// create quid

        // acountant from : { acountant_id , dayin , madin}
        // acountant to : { acountant_id , dayin , madin}

         // quied items - dayin
        //             - madin

        if(!$type){
            $type = 6;
        }


        $qayd_id = Qayd::create([
            'qaydtypeid' =>   $type,
            'date' => $date
        ])->id;
        
        
            
        $qayditemFrom= Qayditem::create([
            'qaydid' =>  $qayd_id,
            'branchid' => $account_from->acountant_id,
            'dayin'=> $account_from->dayin,
            'madin'=> $account_from->madin,
            'topic'=> $notes,
            'date' => Carbon::now()
        ]);
        $qayditemTo= Qayditem::create([
            'qaydid' =>  $qayd_id,
            'branchid' => $account_to->acountant_id,
            'dayin'=> $account_to->dayin,
            'madin'=> $account_to->madin,
            'topic'=> $notes,
            'date' => Carbon::now()
        ]);

        return $qayd_id;
    }
       
        
}
