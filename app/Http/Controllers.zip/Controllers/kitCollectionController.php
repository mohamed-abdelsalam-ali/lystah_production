<?php

namespace App\Http\Controllers;

use App\Models\AllKit;
use App\Models\AllPart;
use App\Models\BuyTransaction;
use App\Models\Kit;
use App\Models\KitPart;
use App\Models\OrderSupplier;
use App\Models\Part;
use App\Models\PartNumber;
use App\Models\PartQuality;
use App\Models\Replyorder;
use App\Models\Source;
use App\Models\Status;
use App\Models\Store;
use App\Models\StoresLog;
use App\Models\Supplier;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PhpParser\Node\Expr\Cast\Object_;

class kitCollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
     $allkits = AllKit::where('remain_amount','>',0)->groupBy(['part_id','source_id','status_id','quality_id'])->select(DB::raw("SUM(`remain_amount`) AS `amount`"),'part_id','status_id','quality_id','source_id')->with('kit')->get();
     $allsupplier = Supplier::all();
     $kits = Kit::with('kit_parts')->get();
     $allparts = AllPart::where('remain_amount','>',0)->groupBy(['part_id','status_id','quality_id','source_id'])->select(DB::raw("SUM(`remain_amount`) AS `amount`"), 'part_id')->get();
     $allsources = Source::all();
     $allstatus = Status::all();
     $allquality = PartQuality::all();
       return view('kitCollectionIndex',compact('allkits','allparts','allsupplier','kits','allsources','allstatus','allquality'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function kitInfo(Request $request)
    {
        //
        // return $request->kit_id;
        $kitPart = KitPart::where('kit_id',$request->kit_id)->with('part')->with('source')->with('status')->with('part_quality')->get();
        return $kitPartAvailable = $this->calculateKits($request->kit_id);

    }

    public function calculateKits($kit_id){
        $responseArr=[];
        $allparts=[];

          $kitParts = KitPart::where('kit_id',$kit_id)->with('part')->with('source')->with('status')->with('part_quality')->get();
          if(count($kitParts) > 0){
            $responseArr['component'] = $kitParts;
          }else{
            $responseArr['component'] = [];
          }
          // search allpart to found parts availability
          $minArr=[];
          $availableSumArr=[];
          $min=0;
        foreach ($kitParts as $key => $part) {
            // return $part;
            $availableSum = 0;
            $allpartx =AllPart::where('remain_amount','>=',$part->amount)
            ->where('part_id','=',$part->part_id)
            ->groupBy(['part_id','status_id','quality_id','source_id'])
            ->select(DB::raw("SUM(`remain_amount`) AS `amount`"), 'part_id','status_id','quality_id','source_id')
            ->with('part')
            ->with('source')
            ->with('status')
            ->with('part_quality')
            ->get();



            foreach ($allpartx as $key => $xx) {
                # code...

                if(floor($xx->amount / $part->amount) > 0  ){
                    $xx['available']= floor($xx->amount / $part->amount);
                    $availableSum +=floor($xx->amount / $part->amount);
                    array_push($minArr,floor($xx->amount / $part->amount));
                }
            }

            array_push($availableSumArr ,$availableSum );
            if(count($allpartx)>0){
                array_push($allparts,$allpartx);
            }

        }
        // return $allparts;
       if(count($kitParts) == count($allparts)){
            $responseArr['parts'] = $allparts;
            //$min = min($minArr);
            //  $min = count($minArr)>0 ? min($minArr) : 0;
             $min = count($availableSumArr)>0 ? min($availableSumArr) : 0;



            $responseArr['message'] = "يمكن تجميع كيت من المخازن";
       }else{
            // return "لا يوجد قطع كافية لعمل كيت";
            $responseArr['message'] = "لا يوجد قطع كافية لعمل كيت";
            $responseArr['parts'] = [];

       }

       $stores = Store::all();

       foreach ($stores as $key1 => $store) {
            $store_model = ucfirst($store->table_name);
            if ($store_model == 'Damaged_parts') {
                $store_model = 'DamagedPart';
            }
            $partIn=[];
            foreach ($kitParts as $key => $part) {
                // return $part;
                $entity_tbl = 'App\\Models\\' . $store_model;
                 $partsIneachStore= $entity_tbl::
                leftjoin('stores_log', $store->table_name . '.store_log_id', '=', 'stores_log.id')
                ->leftjoin('all_parts', 'stores_log.All_part_id', '=', 'all_parts.id')
                ->where('stores_log.type_id', '=', '1')
                ->where('all_parts.remain_amount', '>', '0')
                ->where('all_parts.part_id','=',$part->part_id)
                ->groupBy(['all_parts.part_id','all_parts.status_id','all_parts.quality_id','all_parts.source_id'])
                ->select(DB::raw("SUM($store->table_name.amount) AS `amount`"),'all_parts.part_id','status_id','quality_id','source_id')->get();

                foreach ($partsIneachStore as $key => $row) {
                    $row['part']=Part::find($row->part_id);
                    $row['source']=Source::find($row->source_id);
                    $row['status']=Status::find($row->status_id);
                    $row['quality']=PartQuality::find($row->quality_id);

                    $row['price']= Replyorder::where('part_id',$row->part_id)->where('part_type_id',1)->where('source_id',$row->source_id)->where('status_id',$row->status_id)->where('quality_id',$row->quality_id)->with('order_supplier.currency_type.currencies')->orderBy('id','DESC')->first();
                }
                if(count($partsIneachStore) > 0){
                 array_push($partIn , $partsIneachStore );
                }
            }
            $store->partIn = $partIn;


       }

       $responseArr['min']=$min;
       $responseArr['Stores']=$stores;
        //    $responseArr['Stores']="لسه";
        // return $kitParts[0]['kit_id'];
        $kit_data=AllKit::where("part_id",'=',$kitParts[0]['kit_id'])->get();
        if (count($kit_data) > 0) {
            # code...
            $responseArr['kitInstores'] =  $this->PartInStoresCount($kit_data[0]->part_id,$kit_data[0]->source_id,$kit_data[0]->status_id,$kit_data[0]->quality_id,6);
        }else{
            $responseArr['kitInstores'] =[];
        }




       return $responseArr;


    }
    public function create()
    {
        //
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //



    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
    public function PartInStoresCount($partId , $sourceId,$statusId,$qualityId,$type){

        // get all stores
        $stores = Store::all();

        // if($type == 1){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_kits','stores_log.All_part_id','=','all_kits.id')
                ->where('all_kits.part_id','=',$partId)
                ->where('all_kits.source_id','=',$sourceId)
                ->where('all_kits.status_id','=',$statusId)
                ->where('all_kits.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_kits','stores_log.All_part_id','=','all_kits.id')
                ->where('all_kits.part_id','=',$partId)
                ->where('all_kits.source_id','=',$sourceId)
                ->where('all_kits.status_id','=',$statusId)
                ->where('all_kits.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        // }



    }

    public function save_kit_collection(Request $request ){
        // return $request;

        $store = Store::find($request->storeId);

        $store_model=ucfirst($store->table_name);
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        $entity ='App\\Models\\'.$store_model;

        foreach ($request->kitItems as $key => $value) {
             $part_id = $value['part_id'];
             $source_id = $value['source_id'];
             $status_id = $value['status_id'];
             $status_id = $value['quality_id'];
             $amount = $value['amount'];


            // return $entity::with(['stores_log'=>function($x)use ($part_id , $source_id , $status_id , $quality_id) {
            //     $x->with(['all_parts' => function($q) use ($part_id , $source_id , $status_id , $quality_id) {
            //         $q->where('part_id',$part_id)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->get();
            //     }]);
            // }])->get();

             $currentRow = DB::table($store->table_name)
            ->select($store->table_name.'.*')
            ->join('stores_log',$store->table_name.'.store_log_id','=','stores_log.id')
            ->join('all_parts','stores_log.All_part_id','=','all_parts.id')
            ->where('all_parts.part_id','=',$part_id)
            ->where('all_parts.source_id','=',$source_id)
            ->where('all_parts.status_id','=',$status_id)
            ->where('all_parts.quality_id','=',$status_id)
            ->where('stores_log.status','=',3);
            // ->decrement('remain_amount',$amount);

            $currentRow->decrement('remain_amount',$amount);   /// allpart
            $currentRow->decrement($store->table_name.'.amount',$amount); // store

        }



        // decrese store allparts
        // decrese allparts

        // create kit
        // create

        //buy transaction
        // orderSupplier
        // all_kit
        $buytrans_id = BuyTransaction::create([
            'date' => Carbon::now(),
            'company_id' => 10,
            'final' => 3,
            'creation_date' => Carbon::now()
        ])->id;


        $orderSupplier_id = OrderSupplier::create([
            'transaction_id' => $buytrans_id,
            'supplier_id' => $request->supplier,
            'deliver_date' => Carbon::now(),
            'currency_id' => 400,
            'total_price' => $request->buyPrice,
            'container_size' =>0 ,
            'confirmation_date' => Carbon::now()
        ])->id;
        Replyorder::create([
            'order_supplier_id' => $orderSupplier_id,
            'part_id' => $request->kit_id,
            'price' => $request->buyPrice,
            'amount' => $request->neededKit,
            'source_id' => $request->source,
            'status_id' => $request->status,
            'creation_date' => Carbon::now(),
            'quality_id' => $request->quality,
            'part_type_id' => 6
         ]);
        $allkit_id = AllKit::create([
            'part_id' => $request->kit_id,
            'order_supplier_id' => $orderSupplier_id, // الشركة
            'amount' => $request->neededKit,
            'remain_amount' => $request->neededKit,
            'source_id' => $request->source, // محلي
            'status_id' => $request->status, // محلي
            'buy_price' => $request->buyPrice, // شراء - بيع
            'insertion_date' => Carbon::now(),
            'quality_id' => $request->quality, // محلي
            'lastupdate' => Carbon::now()
        ])->id;
        // store_log
        $storelog_id = StoresLog::create([
            'All_part_id' => $allkit_id,
            'store_action_id' => 3,
            'store_id' => $request->storeId,
            'amount' => $request->neededKit,
            'date' => Carbon::now(),
            'user_id' => Auth::user()->id,
            'status' => 3,
            'type_id' => 6
        ])->id;



        // store
            $entity::create([
                'part_id' => $request->kit_id ,
                'amount' => $request->neededKit,
                'supplier_order_id' => $orderSupplier_id,
                'notes' => 'تجميع كيت داخلي',
                'type_id' => 6,
                'store_log_id' => $storelog_id,
                'date' => Carbon::now()
            ]);

            return true;


    }
}
