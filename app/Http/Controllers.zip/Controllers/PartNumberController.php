<?php

namespace App\Http\Controllers;

use App\Models\PartNumber;
use App\Models\Part;
use Illuminate\Http\Request;
use DataTables;


class PartNumberController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(PartNumber $partNumber)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PartNumber $partNumber)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, PartNumber $partNumber)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PartNumber $partNumber)
    {
        //
    }

    public function partNumberIndex(Request $request)
    {
        if ($request->ajax()) {

            $data = PartNumber::with('part')->with('supplier')->get();
            // return $data;
            return Datatables::of($data)
                    ->addIndexColumn()
                    ->addColumn('PartNumber',function($row){
                        return $row->number ;
                    })
                    ->addColumn('ArabicName',function($row){
                        return $row->part->name ;
                    })
                    ->addColumn('EnglishName',function($row){
                        return $row->part->name_eng ;
                    })
                    ->addColumn('supplier',function($row){
                        $html = "";
                        if(isset($row->supplier)){
                           if($row->flag_OM == "1"){
                                $html .='<text class="text-danger">'.$row->supplier->name.'</text>';
                            }else{
                                $html .='<text>'.$row->supplier->name.'</text>';
                            } 
                        }else{
                            $html = '----';
                        }
                            

                        return $html;
                    })
                    ->rawColumns(['PartNumber','ArabicName','EnglishName','supplier'])
                    ->make(true);
        }


    }
    
}
