<?php

namespace App\Http\Controllers;

use App\Models\Equip;
use App\Models\EquipSpec;
use App\Models\EquipNumber;
use App\Models\RelatedEquip;
use App\Models\Series;
use App\Models\EquipImage;
use App\Models\EquipDetail;
use App\Models\BrandType;
use App\Models\Brand;
use App\Models\Model;
use App\Models\BuyTransaction;
use App\Models\OrderSupplier;
use App\Models\Replyorder;
use App\Models\Store;
use App\Models\AllEquip;
use App\Models\StoresLog;
use App\Models\InvoiceImage;

use File;

use DataTables;
use Illuminate\Support\Facades\DB;

use Carbon\Carbon;
use Illuminate\Http\Request;

class EquipsController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function indexWithRequest(Request $request)
     {
         if ($request->ajax()) {
             $data = Equip::all();
             return Datatables::of($data)
                 ->addIndexColumn()
                 ->addColumn('name',function($row){
                     return $row->name ;
                 })
                 ->addColumn('related_equips',function($row){
                    $relatedEquip = RelatedEquip::where('equip_id', $row->id)->get();
                    $html = "";
                    foreach ($relatedEquip as $key => $value) {
                        $html .='<li>'.$value->parts->name.'</li>';
                    }
                    return $html;
                })
                ->addColumn('equipSeries',function($row){
                    $equipSeries= Series::where('id',$row->model_id)->get();
                    foreach ($equipSeries as $key => $value) {
                        return isset($value->name) ? $value->name : '--';
                    }
                })
                 ->addColumn('equipBrand',function($row){
                    $equipModel = Model::where('id',$row->model_id)->get();
                    $html="";
                    foreach ($equipModel as $key => $value) {
                       $html .= $value->brand->name;
                    }
                    return $html;
                })
                 ->addColumn('Image',function($row){
                     $equipImage = EquipImage::where('equip_id',$row->id)->get();
                     $html="";
                     foreach ($equipImage as $key => $value) {
                        $html = $html . '<img class="rounded-circle header-profile-user" src="assets/equip_images/'. $value->image_name.'" alt="Emara">';
                     }
                     return $html;
                 })
                 ->addColumn('action', function($row){

                     $btn = '<a  data-bs-toggle="modal"  equip_id_value="'.$row->id.'"  data-bs-target="#editEquip"
                     data-toggle="tooltip" data-original-title="Edit" class="btn btn-primary btn-sm editEquipB"><i class="ri-edit-line editEquipButton"></i></a>';
                     $btn = $btn.' <form action="'.route("equip.destroy",$row->id).'" method="POST">'
                             . csrf_field()
                             . method_field('DELETE')
                             .'<input type="submit" value="Delete" class= "btn btn-danger">'.
                             '</form>';
                    $btn = $btn.'<a href="'.route("equip.print",$row->id ).'"
                    class="btn btn-success btn-sm printEquip">Print<i class="ri-print-line"></i></a>';
                    return $btn;
                 })
                 ->rawColumns(['name','related_equips','equipBrand','equipSeries','Image','action'])
                 ->make(true);
         }
     }

     public function indexWithID(Equip $equipId)
    {

        $all_equip = AllEquip::where('part_id' , $equipId->id)->get();
        $equip=Equip::where('id' , $equipId->id)
        ->with(['all_equips'=>function($query){
                return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['replyorders'=>function($query2){
                        return $query2->get();
                }])->get();
                }]);
            }])

        ->with(['equip_details'=>function($query3){
            return $query3->with(['equip_spec'=>function($query4){
                return $query4->get();
            }])->get();
        }])
        ->with(['series'=> function($query8){
            return $query8->with(['model'=>function($query9){
                return $query9->with('brand')->with('brand_type')->get();
            }])->get();
        }])
        ->with('equip_images')
        ->with(['invoice_images'=>function($query5){
            return $query5->where('part_type_id' , '5')->get();
        }])
        ->with(['related_equips'=>function($query6){
            return $query6->with(['parts'=>function($query7){
                return $query7->get();
            }])->get();
        }])
        ->get();
        $store_log = StoresLog::where('All_part_id' , $all_equip[0]->id )->where( 'type_id' , '5')->get();
        return([$equip,$store_log]);

    }
    public function index()
    {
        return Equip::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // return $request;
        Equip::create($request->all());
        $equip_id=Equip::max('id');
        if(isset($request->relatedPart)){
            for ($i=0; $i < count($request->relatedPart) ; $i++) {
                RelatedEquip::create(['equip_id' => $equip_id , 'sug_part_id' => $request->relatedPart[$i]]);
            }
        }
        if(isset($request->specs)){
            for ($i=0; $i < count($request->specs) ; $i++) {
                if($request->specs[$i] != null){
                    $specs = new EquipSpec();
                    $specs->name = $request->specs[$i];
                    $specs->general_flag = $equip_id;
                    $specs->save();
                    $specDetail = new EquipDetail();
                    $specDetail->equipspecs_id = $specs->id;
                    $specDetail->equip_id = $equip_id;
                    if(isset($request->specsval)){
                        $specDetail->value = $request->specsval[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecs)){
            for ($j=0; $j < count($request->oldspecsval) ; $j++) {
                if($request->oldspecsval[$j] != null){
                    EquipDetail::create(['equipspecs_id'=> $request->oldSpecs[$j] ,'equip_id'=> $equip_id ,'value' => $request->oldspecsval[$j]]);
                }else{
                    continue;
                }

            }
        }
        if(isset($request->equipImg)){
            for ($i=0; $i < count($request->equipImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->equipImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->equipImg[$i]->extension() ;
                $request->equipImg[$i]->move(public_path('assets/equip_images'), $imageName);
                EquipImage::create(['equip_id' => $equip_id ,'name' => $namewithoutchar,  'image_name' => $imageName]);

            }
        }
        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id ,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg)){
            for ($i=0; $i < count($request->invoiceImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg[$i]->extension() ;
                // $invoice_url = "assets/invoice_images".$imageName;
                $request->invoiceImg[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $equip_id ,'name' => $namewithoutchar,  'image_name' => $imageName , 'part_type_id' =>'5' ]);
            }
        }
        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplayer_id,'status' =>'0' , 'container_size'=> $request->container_size , 'total_price' => $request->buy_price , 'bank_account' => $request->bank_account, 'container_size' => $request->container_size , 'deliver_date'=> $request->deliverydate , 'currency_id' => $request->currency_id ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $equip_id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'5' , 'price' => $request->buy_price, 'source_id' => $request->source_id ,'quality_id' => $request->quality_id, 'status_id' => $request->status_persentage ]);
        AllEquip::create(['part_id' => $equip_id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id , 'status_id' => $request->status_persentage , 'buy_price' => $request->buy_price , 'insertion_date' => Carbon::now() ,'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id ,'lastupdate' => Carbon::now() ]);
        $all_equip_id = AllEquip::max('id');
        StoresLog::create(['All_part_id' => $all_equip_id , 'store_action_id' => '3' , 'store_id' => $request->store_id  , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '5']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);

                    // return $storeClsName;
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $equip_id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='5'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }

        return back()->with('success','You Have Successfully save Equipment.');


    }

    /**
     * Display the specified resource.
     */
    public function show(Equip $equip)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Equip $equip)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Equip $equip)
    {
        // return $request;
        $imgURLsInp = explode(',', $request->imgURLsInp[0]) ;
        $imgURLsInpInvoice = explode(',', $request->imgURLsInpInvoice[0]) ;
        for($i = 0 ; $i< count($imgURLsInpInvoice) ; $i++){
            if($imgURLsInpInvoice[$i] != null){
                $equip->invoice_images()->where('image_name', $imgURLsInpInvoice[$i])->delete();
            }
        }
        for($i = 0 ; $i< count($imgURLsInp) ; $i++){
            if($imgURLsInp[$i] != null){
                $equip->equip_images()->where('image_name', $imgURLsInp[$i])->delete();
            }
        }

        $relatedEquip= RelatedEquip::where('equip_id' ,$equip->id)->get();
        if(isset($relatedEquip)){
            $relatedEquip->each->delete();
        }

        $equip->equip_details()->delete();
        $equip_specs= EquipSpec::where('general_flag' , $equip->id)->get();
        if(count($equip_specs)>0){
            $equip_specs->each->delete();
        }

        $all_equip = $equip->all_equips()->first();
        if(isset($all_equip)){
            $order_supplier_id = $all_equip->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_equip->id)->where('type_id' , '5')->first();
        }

        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();
            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $equip->id)->where('type_id' , '5')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_equip)){
            AllEquip::find($all_equip->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $equip->id)->where('part_type_id' , '5')->first();

        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        $equip->update(['name' => $request->name_edit , 'name_eng' => $request->name_eng_edit , 'desc' => $request->desc_edit , 'year' => $request->year_edit , 'hours' => $request->hours_edit , 'status_persentage' => $request->status_persentage_edit , 'tank_capacity' => $request->tank_capacity_edit , 'limit_order' => $request->limit_order_edit ,'flage_limit_order' => $request->flage_limit_order_edit ,'last_sevice_date' => $request->last_sevice_date_edit , 'model_id' => $request->model_id_edit , 'supplayer_id'=> $request->supplayer_id_edit , 'company_id' => $request->company_id ,'currency_id' => $request->currency_id_edit , 'source_id' => $request->source_id_edit , 'quality_id' => $request->quality_id_edit , 'buy_price' => $request->buy_price_edit ]);

        if(isset($request->specs_edit)){
            for ($i=0; $i < count($request->specs_edit) ; $i++) {
                if($request->specs_edit[$i] != null){
                    $specs = new EquipSpec();
                    $specs->name = $request->specs_edit[$i];
                    $specs->general_flag = $equip->id;
                    $specs->save();
                    $specDetail = new EquipDetail();
                    $specDetail->equipspecs_id = $specs->id;
                    $specDetail->equip_id = $equip->id;
                    if(isset($request->specsval_edit)){
                        $specDetail->value = $request->specsval_edit[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecs_edit)){
            for ($j=0; $j < count($request->oldSpecs_edit) ; $j++) {
                if($request->oldSpecs_edit[$j] != null){
                    EquipDetail::create(['equipspecs_id'=> $request->oldSpecs_edit[$j] ,'equip_id'=> $equip->id ,'value' => $request->oldspecsval_edit[$j]]);
                }else{
                    continue;
                }
            }
        }

        if(isset($request->relatedPartEdit)){
            for ($i=0; $i < count($request->relatedPartEdit) ; $i++) {
                RelatedEquip::create(['equip_id' => $equip->id , 'sug_part_id' => $request->relatedPartEdit[$i]]);
            }
        }

        if(isset($request->equipImg_edit)){
            for ($i=0; $i < count($request->equipImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->equipImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->equipImg_edit[$i]->extension() ;
                $request->equipImg_edit[$i]->move(public_path('assets/equip_images'), $imageName);
                EquipImage::create(['equip_id' => $equip->id , 'name' => $namewithoutchar, 'image_name' => $imageName]);
            }
        }

        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg_edit)){
            for ($i=0; $i < count($request->invoiceImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg_edit[$i]->extension() ;
                $request->invoiceImg_edit[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $equip->id ,'part_type_id' => '5' ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }

        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplayer_id_edit,'status' =>'0' , 'container_size'=> $request->container_size_edit , 'total_price' => $request->buy_price_edit ,'deliver_date'=> $request->deliverydate_edit , 'bank_account' => $request->bank_account_edit, 'currency_id' => $request->currency_id_edit ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $equip->id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'5' , 'price' => $request->buy_price_edit, 'source_id' => $request->source_id_edit ,'quality_id' => $request->quality_id_edit, 'status_id' => $request->status_persentage_edit ]);
        AllEquip::create(['part_id' => $equip->id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id_edit , 'status_id' => $request->status_id_edit , 'buy_price' => $request->buy_price_edit , 'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id_edit , 'lastupdate' => Carbon::now()]);
        $all_equip_id = AllEquip::max('id');
        StoresLog::create(['All_part_id' => $all_equip_id , 'store_action_id' => '3' , 'store_id' => $request->store_id_edit , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '5']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id_edit)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $equip->id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='5'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }
        return back()->with('success','You Have Successfully Updated Equipment.');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Equip $equip)
    {
        $image_name= InvoiceImage::where('part_id' , $equip->id)->where('part_type_id' , '5')->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/invoice_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $invoice_image= InvoiceImage::where('part_id' , $equip->id)->where('part_type_id' , '5')->get();
        if(isset($invoice_image)){
            $invoice_image->each->delete();
        }


        $image_name = $equip->equip_images()->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/equip_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $equip_image= EquipImage::where('equip_id' , $equip->id)->get();
        if(isset($equip_image)){
            $equip_image->each->delete();
        }
        $relatedEquip= RelatedEquip::where('equip_id' ,$equip->id)->get();
        if(isset($relatedEquip)){
            $relatedEquip->each->delete();
        }

        $equip->equip_details()->delete();
        $equip_specs= EquipSpec::where('general_flag' , $equip->id)->get();
        if(count($equip_specs)>0){
        $equip_specs->each->delete();
            }
        $all_equip = $equip->all_equips()->first();
        if(isset($all_equip)){
            $order_supplier_id = $all_equip->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_equip->id)->where('type_id' , '5')->first();
        }
        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();
            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $equip->id)->where('type_id' , '5')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_equip)){
            AllEquip::find($all_equip->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $equip->id)->where('part_type_id' , '5')->first();

        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        Equip::where('id' , $equip->id)->delete();
        return back()->with('success','You Have Successfully Deleted Equipment.');
    }

    public function equipspecs(){

        return EquipSpec::where('general_flag','0')->get();
    }

    public function equipBrand(){
        $brandType = BrandType::all();
        $brand = Brand::all();
        return[$brandType , $brand];
    }

    public function equipmodel($brandId,$ttypeid){
        return Model::where('brand_id',$brandId)->where('type_id',$ttypeid)->get();
    }

    public function equipseries($modelId){
        $series =  Series::where('model_id',$modelId)->with('model')->get();
        return $series;
    }
    public function printequip($equip_id)
    {
        $equip =  Equip::where('id' , $equip_id)

        ->with(['all_equips'=>function($query){
            return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['buy_transaction'=>function($query2){
                        return $query2->get();
                }])->with('currency_type')
                    ->with('supplier')
                    ->get();
            }])
            ->with('source')
            ->with('status')
            ->with('part_quality')
            ->get();
        }])
        ->with(['equip_details'=>function($query){
            return $query->with(['equip_spec'=>function($query1){
                return $query1->get();
            }])->get();
        }])
        ->with(['series'=>function($query){
            return $query->with(['model'=>function($query1){
                    return $query1->with(['brand'=>function($query2){
                        return $query2->get();
                }])->get();
            }]);
        }])
        ->with('equip_images')->first();
        // return $equip;
        return view("printEquip",compact("equip"));
    }
}