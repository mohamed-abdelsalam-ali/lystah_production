<?php

namespace App\Http\Controllers;

use App\Models\Service;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $all_services = Service::all();
        return view('service.index',compact('all_services'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // return $request;
        if ($request->hasfile('service_img')){
            $var = date_create();
            $time = date_format($var, 'YmdHis');
            $image_service= $time . '-' . $request->name . '-' . $request->service_img->getClientOriginalName();
            $request->service_img->move(public_path('service_images'), $image_service);
            Service::create([
                'name'=>$request->name,
                'service_img'=>$image_service,

            ]);
          

        }else{
            Service::create([
                'name'=>$request->name,

            ]);

        }
        session()->flash("success", "تم الاضافة بنجاح");
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        // return $request;
        $service=Service::where('id',$request->service_id)->first();
        // return $company;
        if ($request->hasfile('service_img')){
            if(isset($service->service_img))
            {
             $image_path = public_path() . '/service_images' . '/' . $service->service_img;
             unlink($image_path);
     
            }
            $var = date_create();
            $time = date_format($var, 'YmdHis');
            $image_service= $time . '-' . $request->name . '-' . $request->service_img->getClientOriginalName();
            $request->service_img->move(public_path('service_images'), $image_service);
            $service->update([
                'name'=>$request->name,
                'service_img'=>$image_service,

            ]);
        }else{
            $service->update([
                'name'=>$request->name,

            ]);
            
        }
        session()->flash("success", "تم التعديل بنجاح");
        return redirect()->route('service.index');
       
    }


    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        // return $request;
        $service=Service::where('id',$request->service_id)->first();
        // return $company;
        if(isset($service->service_img))
            {
             $image_path = public_path() . '/service_images' . '/' . $service->service_img;
             unlink($image_path);
     
            }
        $service->delete();
        session()->flash("success", "تم الحذف بنجاح");
        return redirect()->route('service.index');


    }
}
