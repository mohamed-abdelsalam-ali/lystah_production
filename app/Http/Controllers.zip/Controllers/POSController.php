<?php

namespace App\Http\Controllers;

use App\Models\AllKit;
use App\Models\AllPart;
use App\Models\Brand;
use App\Models\BrandType;
use App\Models\Client;
use App\Models\Group;
use App\Models\Invoice;
use App\Models\InvoiceClientMadyonea;
use App\Models\InvoiceItem;
use App\Models\InvoicesTax;
use App\Models\Part;
use App\Models\PricingType;
use App\Models\Wheel;
use App\Models\PartImage;
use App\Models\WheelImage;
use App\Models\Tractor;
use App\Models\SaleType;
use App\Models\TractorImage;
use App\Models\KitImage;
use App\Models\Kit;

use App\Models\Model;
use App\Models\Quote;
use App\Models\QuoteItem;
use App\Models\PartModel;
use App\Models\SalePricing;
use App\Models\Source;
use App\Models\Status;
use App\Models\PartQuality;
use App\Models\Series;
use App\Models\Store;
use App\Models\StoreSection;
use App\Models\StoresLog;
use App\Models\StoreStructure;
use App\Models\SubGroup;
use App\Models\Tax;
use App\Models\AllTractor;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\AllWheel;
use App\Models\MoneySafe;
use Illuminate\Support\Facades\DB;
use DataTables;
use Illuminate\Support\Facades\Auth;

use function PHPSTORM_META\type;

class POSController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public $storeIdd;

    public function index(Request $request)
    {
        //
        // return $request;
        $storeId = $request->storeId;
        $store_data=Store::where('id','=',$storeId)->get();
        $items_part=  $this->get_parts_info($store_data[0]->table_name);
        // return $items_part;
        $items_wheel=  $this->get_wheel_info($store_data[0]->table_name);
        $items_tractor=  $this->get_tractor_info($store_data[0]->table_name);
        $items_clarck=  $this->get_clarck_info($store_data[0]->table_name);
        $items_equip=  $this->get_equip_info($store_data[0]->table_name);
        $items_kit=  $this->get_kit_info($store_data[0]->table_name);

        $allItems = new \Illuminate\Database\Eloquent\Collection; //Create empty collection which we know has the merge() method
        $allItems = $allItems->concat($items_part);
        $allItems = $allItems->concat($items_wheel);
        $allItems = $allItems->concat($items_tractor);
        $allItems = $allItems->concat($items_clarck);
        $allItems = $allItems->concat($items_equip);
        $allItems = $allItems->concat($items_kit);
        // $data_inbox= $this->inbox_admin();
        $allStores =Store::all();

        $allBrands =Brand::all();
        $allGroups =Group::all();
        $alltaxes=Tax::all();
        $clients = Client::with('invoices')->with('invoice_client_madyoneas')->get();
        // return view('ecommerce.index',compact('allBrands','allGroups','allItems'));
        // return $items_part;
        $allSections = StoreStructure::where('store_id',$storeId)->with(['store_sections'=> function($q){
            $q->with('part')->with('source')->with('type')->with('status')->with('part_quality')->get();
        }])->get();

        $allClients = Client::with('invoices')->with('invoice_client_madyoneas')->get();

        $allGroups = Group::all();
        $allSGroups = SubGroup::all();
        $Btype = BrandType::all();
        $allbrand =Brand::all();
        $allmodel= Model::all();
        $allseries = Series::all();
        $allprices = PricingType::all();
        $this->storeIdd=$storeId;
        // $data_inbox= $this->inbox_admin();
        $store_inbox= $this->store_inbox($storeId);
        // $store_item= $this->store_inbox($storeId);
        // return $allItems;
        return view('pos_dt',compact('allBrands','store_data','allItems','alltaxes','clients','allSections','allClients','store_inbox','allStores','allGroups','allSGroups','Btype','allbrand','allmodel','allseries','allprices'));


    }

    public function shoptest()
    {
        //
        // return $request;
        $storeId = 5;
        $store_data=Store::where('id','=',$storeId)->get();
        $items_part=  $this->get_parts_info($store_data[0]->table_name);

        $items_wheel=  $this->get_wheel_info($store_data[0]->table_name);
        $items_tractor=  $this->get_tractor_info($store_data[0]->table_name);
        $items_clarck=  $this->get_clarck_info($store_data[0]->table_name);
        $items_equip=  $this->get_equip_info($store_data[0]->table_name);
        $items_kit=  $this->get_kit_info($store_data[0]->table_name);

        $allItems = new \Illuminate\Database\Eloquent\Collection; //Create empty collection which we know has the merge() method
        $allItems = $allItems->concat($items_part);
        $allItems = $allItems->concat($items_wheel);
        $allItems = $allItems->concat($items_tractor);
        $allItems = $allItems->concat($items_clarck);
        $allItems = $allItems->concat($items_equip);
        $allItems = $allItems->concat($items_kit);
        // $data_inbox= $this->inbox_admin();

        $allBrands =Brand::all();
        $allGroups =Group::all();
        $alltaxes=Tax::all();
        $clients = Client::with('invoices')->with('invoice_client_madyoneas')->get();
        // return view('ecommerce.index',compact('allBrands','allGroups','allItems'));
        // return $allItems;
        $allSections = StoreStructure::where('store_id',$storeId)->with(['store_sections'=> function($q){
            $q->with('part')->with('source')->with('type')->with('status')->with('part_quality')->get();
        }])->get();
        $allClients = Client::with('invoices')->with('invoice_client_madyoneas')->get();
        // return $allClients;
        return view('ecommerce.shop-grid',compact('allBrands','store_data','allItems','alltaxes','clients','allSections','allClients'));


    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function inbox_admin(){

        return StoresLog::with('store_action')->with('type')->with('store')->where('stores_log.status' ,'>=','-1')->where('stores_log.status' ,'<>','1')->get();
    }

    public function store_inbox($storeId){

        return StoresLog::with('store_action')->with('type')->with('store')->where('stores_log.status' ,'=','0')->where('stores_log.store_id' ,'=', $storeId)->whereIn('stores_log.store_action_id' ,[3,1])->get();
    }
    public function store_inbox_history(Store $storeId){


        $inbox_history= StoresLog::where('stores_log.status' ,'=','0')->where('stores_log.store_id' ,'=',$storeId->id)->whereIn('stores_log.store_action_id' ,[3,1])->get();
        $inbox_history_all= [];
        for ($i=0; $i <count($inbox_history) ; $i++) {
            $arr=$this->check_p_type($inbox_history[$i]->type_id);
            $all_data= StoresLog::
            with('type')
            ->with('store')
            ->with('store_action')
            ->join($arr[0],'stores_log.All_part_id','=',$arr[0].'.id')
            ->join('order_supplier',$arr[0].'.order_supplier_id','=','order_supplier.id')
            ->join('supplier','order_supplier.supplier_id','=','supplier.id')
            ->join($arr[2],$arr[0].'.part_id','=',$arr[2].'.id')
            ->join('source',$arr[0].'.source_id','=','source.id')
            ->join('status',$arr[0].'.status_id','=','status.id')
            ->join('part_quality',$arr[0].'.quality_id','=','part_quality.id')
            ->where('stores_log.id','=',$inbox_history[$i]->id)

            ->select('stores_log.amount as trans_amount','stores_log.id as stores_log_id','supplier.name as sup_name','stores_log.*',$arr[0].'.*',$arr[2].'.name as part_name','source.name_arabic as source_name','status.name as staus_name','part_quality.name as quality_name')

            ->get();
            array_push($inbox_history_all,$all_data[0]);
        // return  $all_data;
        }

        // return $inbox_history_all;
        $data_inbox= $this->store_inbox();

        // return $inbox_history_all;

        // return $dataTable->render('store.inbox_admin_transaction',compact('inbox_history_all','data_inbox'));
        return view('store.inbox_admin_transaction',compact('data_inbox'));
    }


    public function store_inbox_history1(Store $storeId ,Request $request ){

        if ($request->ajax()) {
            // event(new \App\Events\SaveTransaction('inbox'));
            $inbox_history= StoresLog::where('stores_log.status' ,'=','0')->where('stores_log.store_id' ,'=',$storeId->id)->whereIn('stores_log.store_action_id' ,[3,1])->get();

            $inbox_history_all= [];
            for ($i=0; $i <count($inbox_history) ; $i++) {
                $arr=$this->check_p_type($inbox_history[$i]->type_id);
                $all_data= StoresLog::
                with('type')
                ->with('store')
                ->with('store_action')
                ->join($arr[0],'stores_log.All_part_id','=',$arr[0].'.id')
                ->join('order_supplier',$arr[0].'.order_supplier_id','=','order_supplier.id')
                ->join('supplier','order_supplier.supplier_id','=','supplier.id')
                ->join($arr[2],$arr[0].'.part_id','=',$arr[2].'.id')
                ->join('source',$arr[0].'.source_id','=','source.id')
                ->join('status',$arr[0].'.status_id','=','status.id')
                ->join('part_quality',$arr[0].'.quality_id','=','part_quality.id')
                ->where('stores_log.id','=',$inbox_history[$i]->id)

                ->select('stores_log.amount as trans_amount','stores_log.id as stores_log_id','supplier.name as sup_name','stores_log.*',$arr[0].'.*',$arr[2].'.name as part_name','source.name_arabic as source_name','status.name as staus_name','part_quality.name as quality_name')

                ->get();
                array_push($inbox_history_all,$all_data[0]);
                // return  $all_data;
            }
            $data = $inbox_history_all;
            // return $data;
            return Datatables::of($data)

                ->make(true);
        }

    }


    public function store_items_history1( $storeId ,Request $request ){
        if ($request->ajax()) {
            // event(new \App\Events\SaveTransaction('inbox'));
            $storeId = $storeId;
            $store_data=Store::where('id','=',$storeId)->get();
            $items_part=  $this->get_parts_info($store_data[0]->table_name);

            $items_wheel=  $this->get_wheel_info($store_data[0]->table_name);
            $items_tractor=  $this->get_tractor_info($store_data[0]->table_name);
            $items_clarck=  $this->get_clarck_info($store_data[0]->table_name);
            $items_equip=  $this->get_equip_info($store_data[0]->table_name);
            $items_kit=  $this->get_kit_info($store_data[0]->table_name);

            $allItems = new \Illuminate\Database\Eloquent\Collection; //Create empty collection which we know has the merge() method
            $allItems = $allItems->concat($items_part);
            $allItems = $allItems->concat($items_wheel);
            $allItems = $allItems->concat($items_tractor);
            $allItems = $allItems->concat($items_clarck);
            $allItems = $allItems->concat($items_equip);
            $allItems = $allItems->concat($items_kit);


        // return $allItems;
            return Datatables::of($allItems)

                ->make(true);
        }

    }

    public function send_to_other_store(Request $request){
        // return $request['data']['P_details'];
        $P_details = $request['data']['P_details'];
        $sent_amount = trim(isset($request['data']['sent_amount']) ?$request['data']['sent_amount'] : NULL);
        $other_store_id = trim(isset($request['data']['other_store_id']) ? $request['data']['other_store_id'] : null);
        $store_id = trim(isset($request['data']['store_id']) ? $request['data']['store_id'] : null);
        $part_id =$P_details['part_id'] ;
        $amount = $P_details['Tamount'] ;
        $type_id = $P_details['type_id'] ;
        $supplier_order_id = $P_details['supplier_order_id'] ;
        // $allPartId = $P_details['All_part_id'] ;
        $Store_log_id=$P_details['store_log_id'] ;
        // return $other_store_id;
        $store_data=Store::where('id',$store_id)->get();

        $other_store_data=Store::where('id',$other_store_id)->get();
        // return $other_store_data[0]['table_name'];

        $res_d=$this->check_p_type($type_id);
        $all_part_table=$res_d[0];
        $all_part_model=$res_d[1];
        $part_table=$res_d[2];
        // return $res_d;
        $entity ='App\\Models\\'.$all_part_model;
        $all_p_data= $entity::where('part_id',$part_id)
                        ->where('source_id',$P_details['source_id'])
                        ->where('status_id',$P_details['status_id'])
                        ->where('quality_id',$P_details['quality_id'])->get();
        // return $all_p_data;
        // $tableName=$request['data'][1]['store_data'][$i]['store_table_name'];
        if($other_store_data[0]['table_name'] == "damaged_parts"){
            $ins_id=StoresLog::create([
                'All_part_id' => $all_p_data[0]['id'],
                'store_action_id' =>6,
                'store_id' => $store_id,
                'amount' => $sent_amount,
                // 'user_id' => auth()->user()->id,
                'status' => 2,
                'date'=>date('Y-m-d H:i:s'),
                'type_id' =>  $type_id,
                'notes' =>  'To :'.$other_store_data[0]['name'],

                ])->id;
                if($ins_id > 0){
                    StoresLog::create([
                        'All_part_id' => $all_p_data[0]['id'],
                        'store_action_id' => 3,
                        'store_id' => $other_store_id,
                        'amount' => $sent_amount,
                        // 'user_id' => auth()->user()->id,
                        'status' => $ins_id,
                        'date'=>date('Y-m-d H:i:s'),
                        'type_id' =>  $type_id,
                        'notes' =>  'from :'.$store_data[0]['name'],

                        ]);
                }

        }else{
            $ins_id=StoresLog::create([
            'All_part_id' => $all_p_data[0]['id'],
            'store_action_id' => 2,
            'store_id' => $store_id,
            'amount' => $sent_amount,
            // 'user_id' => auth()->user()->id,
            'status' => 2,
            'date'=>date('Y-m-d H:i:s'),
            'type_id' =>  $type_id,
            'notes' =>  'To :'.$other_store_data[0]['name'],

            ])->id;
            if($ins_id > 0){
            StoresLog::create([
                'All_part_id' => $all_p_data[0]['id'],
                'store_action_id' => 3,
                'store_id' => $other_store_id,
                'amount' => $sent_amount,
                // 'user_id' => auth()->user()->id,
                'status' => $ins_id,
                'date'=>date('Y-m-d H:i:s'),
                'type_id' =>  $type_id,
                'notes' =>  'from :'.$store_data[0]['name'],

                ]);
        }
    }

    }
    public function check_p_type($pt_id){
        if($pt_id ==1){
            $all_p_table_name='all_parts';
            $all_p_model_name='AllPart';
            $table='Part';
        }elseif ($pt_id ==2) {
            $all_p_table_name='all_wheels';
            $all_p_model_name='AllWheel';
            $table='wheel';            }
        elseif ($pt_id ==3) {
            $all_p_table_name='all_tractors';
            $all_p_model_name='AllTractor';
            $table='tractor';            }
        elseif ($pt_id ==4) {
            $all_p_table_name='all_clarks';
            $all_p_model_name='AllClark';
            $table='clark';            }
        elseif ($pt_id ==5) {
            $all_p_table_name='all_equips';
            $all_p_model_name='AllEquip';
            $table='equip';            }
        elseif ($pt_id ==6) {
            $all_p_table_name='all_kits';
            $all_p_model_name='AllKit';
            $table='kit';            }

            return [$all_p_table_name, $all_p_model_name,$table];
    }


    public function confirm_store (Request $request){

            $Store_log_id = $request->data['Store_log_id'];
            $store_table_name = $request->data['store_table_name'];
            $all_p_id =  $request->data['all_p_id'];
            $amount =  $request->data['accamount'];
            $actual_amount=$request->data['actual_amount'];
            $type_id =  $request->data['type_id'];
            $store_id =  $request->data['store_id'];
            $store_action_id =  $request->data['store_action_id'];
            $flag_completed =  $request->data['flag_completed'];
            $supplier_order_id;

            if ($store_action_id == 1) { //توزيع من يوسف الى المخازن للاستلام والمخزن بيسلم الكمية من هنا//
                // return $store_action_id;
                StoresLog::where('id', $Store_log_id)
               ->update([
                   'status' => 1
                ]);

                StoresLog::create([
                    'All_part_id' =>  $all_p_id,
                    'store_action_id' => 3,
                    'store_id' => $store_id,
                    'amount' => $amount,
                    // 'user_id' => auth()->user()->id,
                    'status' => 1,
                    'date'=>date('Y-m-d H:i:s'),
                    'type_id' => $type_id,

                    ]);
                    if($flag_completed==0){
                        // return 'nnnnnnnnnnnnnnnnnnnnnnnnn';
                        StoresLog::create([
                            'All_part_id' =>  $all_p_id,
                            'store_action_id' => 1,
                            'store_id' => $store_id,
                            'amount' => $actual_amount - $amount,
                            // 'user_id' => auth()->user()->id,
                            'status' => 0,
                            'date'=>date('Y-m-d H:i:s'),
                            'type_id' => $type_id,
                            'notes' =>  'remain to delever ',
                            ]);
                    }
                    // return $request;

                # code...
            }
            elseif ($store_action_id == 3) {


                StoresLog::where('id', $Store_log_id)
                ->update([
                    'status' => 1
                 ]);

                 if($flag_completed==0){
                    // return 'nnnnnnnnnnnnnnnnnnnnnnnnn';
                    StoresLog::create([
                        'All_part_id' =>  $all_p_id,
                        'store_action_id' => 3,
                        'store_id' => $store_id,
                        'amount' => $actual_amount - $amount,
                        // 'user_id' => auth()->user()->id,
                        'status' => 0,
                        'date'=>date('Y-m-d H:i:s'),
                        'type_id' => $type_id,
                        'notes' =>  'remain to delever',
                        ]);
                }

            }
            /*elseif ($store_action_id == 6) {

                $x=StoresLog::where('stores_log.id','=',$Store_log_id)->get('amount');
                $damage_amount=$x[0]->amount;

                $store_model=ucfirst($store_table_name);
                if($store_model=="Damaged_parts"){
                    $store_model="damagedPart";
                }
                $entity ='App\\Models\\'.$store_model;
                $y= $entity::leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                ->where('stores_log.All_part_id','=',$all_p_id)->get();
               $supplier_order_id= $y[0]->supplier_order_id;


               StoresLog::where('status', $Store_log_id)
               ->update([
                   'status' => 1
                ]);


               StoresLog::where('id', $Store_log_id)
               ->update([
                   'status' => 1
                ]);


                $old_s_amount=$entity::where($store_table_name.'.store_log_id','=',  $y[0]->store_log_id)->get('amount');
                $entity::where($store_table_name.'.store_log_id','=',  $y[0]->store_log_id)
               ->update([
                   'amount' =>intval($old_s_amount[0]->amount) - intval($amount),
                   'store_log_id' => $Store_log_id
                ]);
                // $damage_tableName=Store::where()
                $damage_row=DamagedPart::leftjoin('stores_log','damaged_parts.store_log_id','=','stores_log.id')
                ->where('stores_log.All_part_id','=',$all_p_id)
                ->select('stores_log.*','damaged_parts.amount as oldamount','damaged_parts.*')
                ->get();
                // return $damage_row;
                if(count($damage_row)>0){
                    DamagedPart::where('damaged_parts.store_log_id','=', $damage_row[0]->store_log_id)
                    ->update([
                               'amount' =>intval($damage_row[0]->oldamount) + intval($amount),
                               'store_log_id' =>$damage_row[0]->store_log_id
                            ]);
                }else{
                    DamagedPart::create([
                        'all_part_id'=>$all_p_id,
                        'amount'=>$amount,
                        'supplier_order_id'=>$supplier_order_id,
                        'type_id'=>$type_id,
                        'store_log_id'=>$Store_log_id,
                        'date'=>date('Y-m-d H:i:s'),
                    ]);
                }
                // return $store_table_name;




            }*/
            if($Store_log_id > 0){
                $res=$this->check_p_type($type_id);
                // return $res;
                 $all_part_table_name= $res[0];
                $all_part_model_name= $res[1];
                $item_table= $res[2];
                $store_model=ucfirst($store_table_name);
                $entity ='App\\Models\\'.$store_model;
                $y= $entity::leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                ->where('stores_log.All_part_id','=',$all_p_id)
                ->where('stores_log.type_id','=',$type_id)
                ->get();
                // return $y;
                if(count($y) > 0){
                  $supplier_order_id= $y[0]->supplier_order_id;
                }else{
                    $newentity ='App\\Models\\'.$all_part_model_name;
                    $z= $newentity::where('id','=',$all_p_id)->get();

                    $supplier_order_id= $z[0]->order_supplier_id;

                    // return $supplier_order_id;
                }


               $founded_row= $entity::leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
               ->where('stores_log.All_part_id','=',$all_p_id)
               ->where('stores_log.type_id','=',$type_id)
               ->select('stores_log.*',$store_table_name.'.amount as oldamount',$store_table_name.'.*')
               ->get();

               if(count($y)>0){
                $entity::where($store_table_name.'.store_log_id','=', $founded_row[0]->store_log_id)
                ->update([
                           'amount' =>intval($founded_row[0]->oldamount) + intval($amount),
                           'store_log_id' =>$founded_row[0]->store_log_id
                        ]);
            }else{
                $entity::create([
                    'part_id'=>$all_p_id,
                    'amount'=>$amount,
                    'supplier_order_id'=>$supplier_order_id,
                    'type_id'=>$type_id,
                    'store_log_id'=>$Store_log_id,
                    'date'=>date('Y-m-d H:i:s'),
                ]);
            }
        }
        // return $store_id;
        //  event(new \App\Events\StoreTranaction($store_id));
        $store_inbox= $this->store_inbox($store_id);

            return $store_inbox;
    }




    // public function get_parts_info($store_table_name){
    //     $store_model=ucfirst($store_table_name);
    //     $storeId = Store::where('table_name',$store_table_name)->first()->id;
    //     if($store_model=="Damaged_parts"){
    //         $store_model="damagedPart";
    //     }

    //     $all_p_table_name='all_parts';
    //     $all_p_model_name='AllPart';
    //     $table='Part';

    //     $entity_tbl ='App\\Models\\'.$store_model;
    //     $items_arr=$entity_tbl::with('stores_log')->get();
    //     $entity ='App\\Models\\'.$store_model;
    //     $store_data=$entity::
    //                 leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
    //                 // ->where($all_p_table_name.'.part_id','=', $p_id)
    //                 ->where('stores_log.type_id','=','1')
    //                 ->select($store_table_name.'.*' , $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id')->get();
    //     $groups = $store_data->groupBy(
    //         'part_id',
    //         'source_id',
    //         'status_id',
    //         'quality_id'
    //     );
    //     // return $storeId;
    //     return $groupwithcount = $groups->map(function ($group) use ($storeId) {
    //         return [
    //             'part_id' => $group->first()['part_id'], // opposition_id is constant inside the same group, so just take the first or whatever.
    //             'groups' => part::where('id',$group->first()['part_id'])->with(['sub_group'=> function($q){
    //                 $q->with('group')->get();
    //             }])->get(),
    //             'models' => PartModel::where('part_id',$group->first()['part_id'])->with(['series'=> function($q){
    //                 $q->with(['model'=> function($w){
    //                     $w->with('brand')->with('brand_type')->get();
    //                 }])->get();
    //             }])->get(),
    //             'Tamount' => $group->sum('amount'),
    //             'image' => PartImage::where('part_id',$group->first()['part_id'])->get(),
    //             'store_log_id' => $group->first()['store_log_id'],
    //             'date' => $group->first()['date'],
    //             'source_id' => $group->first()['source_id'],
    //             'status_id' => $group->first()['status_id'],
    //             'quality_id' => $group->first()['quality_id'],
    //             'supplier_order_id' => $group->first()['supplier_order_id'],
    //             'type_id' => $group->first()['type_id'],
    //             'p_data'=>'App\\Models\\Part'::with('part_numbers')->find($group->first()['part_id']),
    //             'source'=>'App\\Models\\Source'::where('id','=',$group->first()['source_id'])->get(),
    //             'status'=>'App\\Models\\Status'::where('id','=',$group->first()['status_id'])->get(),
    //             'quality'=>'App\\Models\\PartQuality'::where('id','=',$group->first()['quality_id'])->get(),
    //             'type_N' => 'قطع غيار',
    //             'price' => SalePricing::where('part_id',$group->first()['part_id'])->where('source_id',$group->first()['source_id'])->where('status_id',$group->first()['status_id'])->where('quality_id',$group->first()['quality_id'])->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
    //             'section' => StoreSection::where('part_id',$group->first()['part_id'])->where('source_id',$group->first()['source_id'])->where('status_id',$group->first()['status_id'])->where('quality_id',$group->first()['quality_id'])->where('type_id','1')->where('store_id',$storeId)->with('store_structure')->get() ,
    //             'stores' => $this->PartInStoresCount($group->first()['part_id'],$group->first()['source_id'],$group->first()['status_id'],$group->first()['quality_id'],'1')
    //         ];
    //     });

    // }

    public function get_parts_info($store_table_name){
        $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }

        $all_p_table_name='all_parts';
        $all_p_model_name='AllPart';
        $table='Part';

        $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','1')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();


        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => part::where('id',$group->part_id)->with(['sub_group'=> function($q){
                    $q->with('group')->get();
                }])->get(),
                'models' => PartModel::where('part_id',$group->part_id)->with(['series'=> function($q){
                    $q->with(['model'=> function($w){
                        $w->with('brand')->with('brand_type')->get();
                    }])->get();
                }])->get(),
                'Tamount' => $group->amount,
                'image' => PartImage::where('part_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => $group->first()['type_id'],
                'p_data'=>Part::where('id','=',$group->part_id)->with('part_numbers')->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => 'قطع غيار',
                'allparts'=> AllPart::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','1')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'1')
            ];
        });


    }

    public function get_wheel_info($store_table_name){
      $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        
        $all_p_table_name='all_wheels';
        $all_p_model_name='AllWheel';
        $table='Wheel';

 $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','2')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();

        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => Wheel::where('id',$group->part_id)->get(),
                'models' =>[],
                'Tamount' => $group->amount,
                'image' => WheelImage::where('wheel_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => 2,
                'p_data'=>Wheel::where('id','=',$group->part_id)->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => 'كاوتش',
                'allparts'=> AllWheel::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','2')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','2')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'2')
            ];
        });


    }
    public function get_tractor_info($store_table_name){
         $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        $all_p_table_name='all_tractors';
        $all_p_model_name='AllTractor';
        $table='Tractor';

        $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','3')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();

        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => Tractor::where('id',$group->part_id)->get(),
                'models' =>[],
                'Tamount' => $group->amount,
                'image' => TractorImage::where('tractor_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => 3,
                'p_data'=>Tractor::where('id','=',$group->part_id)->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => 'جرارات',
                'allparts'=> AllTractor::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','3')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','3')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'3')
            ];
        });

        


    }

    public function get_clarck_info($store_table_name){
       $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        $all_p_table_name='all_clarks';
        $all_p_model_name='AllClark';
        $table='Clark';



        $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','4')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();

        
        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => Clark::where('id',$group->part_id)->get(),
                'models' =>[],
                'Tamount' => $group->amount,
                'image' => ClarkImage::where('clark_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => 4,
                'p_data'=>Clark::where('id','=',$group->part_id)->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => 'كلارك',
                'allparts'=> AllClark::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','4')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','4')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'4')
            ];
        });



    }

    public function get_equip_info($store_table_name){
        $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        $all_p_table_name='all_equips';
        $all_p_model_name='AllEquip';
        $table='Equip';


        $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','5')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();

        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => Equip::where('id',$group->part_id)->get(),
                'models' =>[],
                'Tamount' => $group->amount,
                'image' => EquipImage::where('equip_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => 5,
                'p_data'=>Equip::where('id','=',$group->part_id)->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => 'معدات',
                'allparts'=> AllEquip::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','5')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','5')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'5')
            ];
        });



    }

    public function get_kit_info($store_table_name){
        $store_model=ucfirst($store_table_name);
        $storeId = Store::where('table_name',$store_table_name)->first()->id;
        if($store_model=="Damaged_parts"){
            $store_model="damagedPart";
        }
        $all_p_table_name='all_kits';
        $all_p_model_name='AllKit';
        $table='kit';




        $entity_tbl ='App\\Models\\'.$store_model;
        $items_arr=$entity_tbl::with('stores_log')->get();
        $entity ='App\\Models\\'.$store_model;
        $store_data=$entity::
                    leftjoin('stores_log',$store_table_name.'.store_log_id','=','stores_log.id')
                    ->leftjoin($all_p_table_name,'stores_log.All_part_id','=',$all_p_table_name.'.id')
                    // ->where($all_p_table_name.'.part_id','=', $p_id)
                    ->where('stores_log.type_id','=','6')
                    ->select( $all_p_table_name.'.source_id', $all_p_table_name.'.status_id', $all_p_table_name.'.quality_id', $all_p_table_name.'.part_id' );
        // $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')->sum($store_table_name.'.amount')->get();

        $groups = $store_data->groupBy('part_id','source_id','status_id','quality_id')
        ->selectRaw('sum('.$store_table_name.'.amount) as amount')
        ->get();

    
       
        return $groupwithcount = $groups->map(function ($group) use ($storeId) {

            return [
                'part_id' => $group->part_id,
                'groups' => kit::where('id',$group->part_id)->get(),
                'models' =>[],
                'Tamount' => $group->amount,
                'image' => KitImage::where('kit_id',$group->part_id)->get(),
                'store_log_id' => $group->first()['store_log_id'],
                'date' => $group->first()['date'],
                'source_id' => $group->source_id,
                'status_id' => $group->status_id,
                'quality_id' => $group->quality_id,
                'supplier_order_id' => $group->first()['supplier_order_id'],
                'type_id' => 6,
                'p_data'=>kit::where('id','=',$group->part_id)->first(),
                'source'=>Source::where('id','=',$group->source_id)->get(),
                'status'=>Status::where('id','=',$group->status_id)->get(),
                'quality'=>PartQuality::where('id','=',$group->quality_id)->get(),
                'type_N' => ' كيت ',
                'allparts'=> AllKit::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('remain_amount' ,'>',0)->orderBy('id','DESC')->get(),
                'price' => SalePricing::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','6')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get() ,
                'section' => StoreSection::where('part_id',$group->part_id)->where('source_id',$group->source_id)->where('status_id',$group->status_id)->where('quality_id',$group->quality_id)->where('type_id','6')->where('store_id',$storeId)->where('amount','>',0)->with('store_structure')->get() ,
                'stores' => $this->PartInStoresCount($group->part_id,$group->source_id,$group->status_id,$group->quality_id,'6')
            ];
        });




    }

    public function shop(){
        $allBrands =Brand::all();
        $allGroups =Group::all();

        $store_data=Store::where('id','=',5)->get();
        $items_part=  $this->get_parts_info($store_data[0]->table_name);
        $items_wheel=  $this->get_wheel_info($store_data[0]->table_name);
        $items_tractor=  $this->get_tractor_info($store_data[0]->table_name);
        $items_clarck=  $this->get_clarck_info($store_data[0]->table_name);
        $items_equip=  $this->get_equip_info($store_data[0]->table_name);
        $items_kit=  $this->get_kit_info($store_data[0]->table_name);

        $allItems = new \Illuminate\Database\Eloquent\Collection; //Create empty collection which we know has the merge() method
        $allItems = $allItems->concat($items_part);
        $allItems = $allItems->concat($items_wheel);
        $allItems = $allItems->concat($items_tractor);
        $allItems = $allItems->concat($items_clarck);
        $allItems = $allItems->concat($items_equip);
        $allItems = $allItems->concat($items_kit);

        $alltaxes=Tax::all();

        return view('ecommerce.shop-grid',compact('allBrands','allGroups','allItems','alltaxes'));


    }

    public function printpos(Request $request){
        // return $request;

        $cli = Client::where('id',$request->client)->get();
        // return $cli;
        if(count($cli) > 0){
            $cli_id = $cli[0]->id;
        }else{
            $client = new Client();
            $client->name ='';
            $client->tel01=$request->client;
            $client->save();
            $cli_id = $client->id;
        }

        $invoice = new Invoice();

        $invoice->name = Carbon::now();
        $invoice->casher_id = "28";
        $invoice->discount = $request->invDiscount;
        $invoice->actual_price = $request->total;
        $invoice->client_id  = $cli_id;
        $invoice->company_id ="10";
        $invoice->store_id = $request->storeId;
        $invoice->price_without_tax = $request->subtotal;
        $invoice->tax_amount = $request->taxval;
        $invoice->paied = $request->invPaied;
        $invoice->date = Carbon::now();
        $invoice->save();

        /// invoice Tax /////////////////
        if(isset($request->taxes)){
            for ($i=0; $i < count($request->taxes) ; $i++) {
                $invTax = new InvoicesTax();
                $invTax->invoice_id =$invoice->id ;
                $tax= Tax::where('value',$request->taxes[$i])->get();
                $invTax->tax_id=$tax[0]->id;
                $invTax->save();

            }
        }



        //////////////////// Only Part//////////////////////////
        $inv_items = $request->items_part;
        for ($i=0; $i < count($inv_items) ; $i++) {

            $item = explode ("-", $inv_items[$i]) ;
            $part_id = $item[0];
            $source_id = $item[1];
            $status_id = $item[2];
            $quality_id = $item[3];
            $type_id = $item[4];
            $amount = $request->itemAmount[$i];

            $invoiceItems = new InvoiceItem();
            $invoiceItems->date = Carbon::now();

            $invoiceItems->part_id = $part_id;
            $invoiceItems->amount = $amount;
            $invoiceItems->source_id = $source_id;
            $invoiceItems->status_id = $status_id;
            $invoiceItems->quality_id = $quality_id;
            $invoiceItems->part_type_id = $type_id;
            $invoiceItems->invoice_id = $invoice->id;
            $invoiceItems->sale_type = $request->pricetype[$i];
            $invoiceItems->save();


            //// remove from store ///////////////////

            $allparts = AllPart::where('remain_amount','>',0)->where('part_id',$part_id)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->orderBy('id', 'ASC')->get();

            $store = Store::where('id',$request->storeId)->get();
            $store_id = $store[0]->id;
            $store_name = $store[0]->name;
            $store_table_name = $store[0]->table_name;

            try {

                DB::table($store_table_name)->where('part_id', $part_id)->where('supplier_order_id', $allparts[0]->order_supplier_id)->where('type_id', 1)->decrement('amount', $amount);
            } catch (\Throwable $th) {
                //throw $th;
            }

            /////////////////////////////////////


            ////// remove from all parts ////////

            AllPart::where('remain_amount','>',0)->where('part_id',$part_id)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->orderBy('id', 'ASC')->decrement('remain_amount',$amount);

            //////////////////////////////////////
            ////// remove from Sectios ////////
             try {

                DB::table('store_section')->where('part_id', $part_id)->where('supplier_order_id', $allparts[0]->order_supplier_id)->where('type_id', 1)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->decrement('amount', $amount);
            } catch (\Throwable $th) {
                //throw $th;
            }

        }
        /////////////////////adel///////////
        $store=Store::where('id',$request->storeId)->first();
        $total = MoneySafe::where('store_id',$request->storeId)->latest()->first();
        if (isset($total)) {
            MoneySafe::create([
                'notes' =>'مبلغ فاتورة بيع رقم'.' '.$invoice->id.' '.' من عميل '.' '.$cli[0]->name.' '.$store->name,

                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->invPaied,
                'total' => $total->total + $request->invPaied,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->storeId
            ]);
        } else {
            MoneySafe::create([
                'notes' =>'مبلغ فاتورة بيع رقم'.' '.$invoice->id.' '.' من عميل '.' '.$cli[0]->name.' '.$store->name,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->invPaied,
                'total' => $request->invPaied,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->storeId

            ]);
        }


        return redirect()->to('printInvoice/'.$invoice->id);
    }
    public function storeSections(Store $storeId){
        // return $storeId;

        $store = $storeId;
        $sections = StoreStructure::all();
        $newParts = [];
        //////////////////////// StoreParts//////////////////////////////////
         $storeClsName=ucfirst($storeId->table_name);
        $storeClsName ='App\Models\\'.$storeClsName;
        $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
        if($storeId->table_name == "damaged_parts"){
            $storeClsName = "App\Models\\DamagedPart";
        }
        $StoreParts = $storeClsName::select(['part_id','supplier_order_id','amount','store_log_id','type_id'])->get();
// return $StoreParts;
        foreach ($StoreParts as $key => $part) {
            # code...
            // $storeSectionPart = StoreSection::where('store_id',$store->id)->where('part_id',$part->part_id)->where('order_supplier_id',$part->supplier_order_id)->get();
            // $storeSectionPart = StoreSection::where('store_id',$store->id)->where('part_id',$part->part_id)->where('order_supplier_id',$part->supplier_order_id)
            // ->groupBy(['part_id'])->select(['part_id','order_supplier_id','sum(amount) as amount'])->get();

            $storeSectionPart = StoreSection::where('store_id',$store->id)->where('part_id',$part->part_id)->where('order_supplier_id',$part->supplier_order_id)
            ->groupBy('part_id','order_supplier_id','source_id','status_id','quality_id')
            ->selectRaw('part_id, order_supplier_id ,sum(amount) as amount')->get();
            // return $storeSectionPart;
            if(count($storeSectionPart)){
              if($storeSectionPart[0]->amount == $part->amount ){
                continue ;
              }else{
                $difAmount = $part->amount -$storeSectionPart[0]->amount;
                array_push($newParts,['part'=>$part->part_id,'type'=>$part->type_id,'supplier_order_id'=>$storeSectionPart[0]->order_supplier_id , 'amount'=> $difAmount , 'store_log_id'=> $part->store_log_id ]);

              }

            }else{
                array_push($newParts,['part'=>$part->part_id,'type'=>$part->type_id,'supplier_order_id'=>$part->supplier_order_id , 'amount'=> $part->amount , 'store_log_id'=> $part->store_log_id]);

            }
        }
// return $newParts;
        for ($i=0; $i < count($newParts) ; $i++) {


            if( $newParts[$i]['type'] == 1){
                $newParts[$i]['partData'] =Part::where('id',$newParts[$i]['part'])->get();
            }elseif($newParts[$i]['type'] == 2){
                  $newParts[$i]['partData'] =Wheel::where('id',$newParts[$i]['part'])->get();
            }


        }


        return view('storeSections',compact('store','sections','newParts'));

    }
    public function getAllDataInSection(StoreStructure $sectionId, Store $storeId){
        return StoreSection::where('store_id',$storeId->id)->where('section_id',$sectionId->id)
        ->groupBy('part_id','order_supplier_id','type_id','source_id','status_id','quality_id')
            ->selectRaw('part_id,type_id, order_supplier_id ,sum(amount) as amount')
        ->with('part')->with('type')->with('source')->with('status')->with('part_quality')->get();
    }
    public function saveNewSection(Request $request){
        // return $request;

        for ($i=0; $i <count($request->section) ; $i++) {

            $sl = StoresLog::where('id',$request->store_log[$i])->get();
            $allpart = AllPart::where('id',$sl[0]->All_part_id)->get();

            $storeSection = new StoreSection();
            $storeSection->store_id =$request->storelbl;
            $storeSection->section_id =$request->section[$i];
            $storeSection->order_supplier_id =$request->supplier_order_id[$i];
            $storeSection->type_id =1;
            $storeSection->part_id =$request->part_id[$i];
            $storeSection->source_id =$allpart[0]->source_id;
            $storeSection->status_id =$allpart[0]->status_id;
            $storeSection->quality_id =$allpart[0]->quality_id;
            $storeSection->amount =$request->sectionAmount[$i];
            $storeSection->date =Carbon::now();
            $storeSection->save();
        }


        return redirect()->to('storeSections/'.$request->storelbl);

    }

    public function newClientInline ($telNumber){
        $client = new Client();
        $client->name ='';
        $client->tel01=$telNumber;
        $client->save();
        return $client->id;
    }

    public function Clientinvoice(Client $clientId,Store $storeId){
        // return $clientId;
        $store = $storeId;
        $client = $clientId;
        $invoices = Invoice::where('client_id',$client->id)->with('store')->get();
        $invoiceMad = InvoiceClientMadyonea::where('client_id',$client->id)->get();
        // return $invoices;
        return view('clientInvoices',compact('store','client','invoices','invoiceMad'));
    }
    public function Clientinvoiceprice(Client $clientId,Store $storeId){
        // return $clientId;
        $store = $storeId;
        $client = $clientId;
        $quotes = Quote::where('client_id',$client->id)->with(['quoteItems'=>function($q){
            $source = $q->with('source')->get();
            $q->with('status')->get();
            $q->with('part_quality')->get();
            $q->with('pricing_type')->get();
            $q->where('part_type_id','1')->with('part')->get();
        }])->get();
        
       for ($i=0; $i <count($quotes) ; $i++) {
            $quotes[$i]['quoteItems']->map(function ($q) use ($storeId) {
                if($q->part_type_id == 1){
                    $q['allpartsRemain'] = AllPart::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->sum('remain_amount');
                    $q['price'] = SalePricing::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->where('type_id',$q->part_type_id)->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();
                    $q['storeCount'] = $this->PartInStoresCount($q->part_id,$q->source_id,$q->status_id,$q->quality_id,$q->part_type_id);
                }
                
            });
        }
       
       $SaleType=PricingType::all();
       $alltaxes = Tax::all();
       
       $store_data=Store::where('id','=',$storeId->id)->get();
       
       $items_part=  $this->get_parts_info($store_data[0]->table_name);
        
        return view('Clientinvoiceprice',compact('quotes','store','client','SaleType','alltaxes','items_part'));
    }
    public function saveMadyonea(Request $request){
        // return $request;
        $mad = new InvoiceClientMadyonea();
        $mad->client_id = $request->client_id;
        $mad->paied = $request->paied;
        $mad->date = Carbon::now();
        $mad->save();
///////////////////////adel//////////////////////
        $client=Client::where('id',$request->client_id)->first();
        $store=Store::where('id',$request->store_id)->first();

        $total = MoneySafe::where('store_id',$request->store_id)->latest()->first();
        if (isset($total)) {
            MoneySafe::create([
                'notes' => 'سداد مبلغ مديونية من عميل '.' '.$client->name.' '.$store->name ,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->paied,
                'total' => $total->total + $request->paied,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->store_id
            ]);
        } else {
            MoneySafe::create([
                'notes' => 'سداد مبلغ مديونية من عميل '.' '.$client->name.' '.$store->name ,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->paied,
                'total' => $request->paied,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->store_id

            ]);
        }


        return redirect()->to('Clientinvoice/'.$request->client_id.'/'.$request->store_id);
    }
    public function printBarcode ($barcodeTxt , $name){
        // return $name;
        return view('printBarcode',compact('barcodeTxt','name'));

    }

    public function PartInStoresCount($partId , $sourceId,$statusId,$qualityId,$type){

        // get all stores
        $stores = Store::all();

        if($type == 1){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_parts','stores_log.All_part_id','=','all_parts.id')
                ->where('all_parts.part_id','=',$partId)
                ->where('all_parts.source_id','=',$sourceId)
                ->where('all_parts.status_id','=',$statusId)
                ->where('all_parts.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_parts','stores_log.All_part_id','=','all_parts.id')
                ->where('all_parts.part_id','=',$partId)
                ->where('all_parts.source_id','=',$sourceId)
                ->where('all_parts.status_id','=',$statusId)
                ->where('all_parts.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }
        else if($type == 6){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_kits','stores_log.All_part_id','=','all_kits.id')
                ->where('all_kits.part_id','=',$partId)
                ->where('all_kits.source_id','=',$sourceId)
                ->where('all_kits.status_id','=',$statusId)
                ->where('all_kits.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_kits','stores_log.All_part_id','=','all_kits.id')
                ->where('all_kits.part_id','=',$partId)
                ->where('all_kits.source_id','=',$sourceId)
                ->where('all_kits.status_id','=',$statusId)
                ->where('all_kits.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }
        else if($type == 2){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_wheels','stores_log.All_part_id','=','all_wheels.id')
                ->where('all_wheels.part_id','=',$partId)
                ->where('all_wheels.source_id','=',$sourceId)
                ->where('all_wheels.status_id','=',$statusId)
                ->where('all_wheels.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_wheels','stores_log.All_part_id','=','all_wheels.id')
                ->where('all_wheels.part_id','=',$partId)
                ->where('all_wheels.source_id','=',$sourceId)
                ->where('all_wheels.status_id','=',$statusId)
                ->where('all_wheels.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }
        else if($type == 3){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_tractors','stores_log.All_part_id','=','all_tractors.id')
                ->where('all_tractors.part_id','=',$partId)
                ->where('all_tractors.source_id','=',$sourceId)
                ->where('all_tractors.status_id','=',$statusId)
                ->where('all_tractors.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_tractors','stores_log.All_part_id','=','all_tractors.id')
                ->where('all_tractors.part_id','=',$partId)
                ->where('all_tractors.source_id','=',$sourceId)
                ->where('all_tractors.status_id','=',$statusId)
                ->where('all_tractors.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }
        else if($type == 4){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_clarks','stores_log.All_part_id','=','all_clarks.id')
                ->where('all_clarks.part_id','=',$partId)
                ->where('all_clarks.source_id','=',$sourceId)
                ->where('all_clarks.status_id','=',$statusId)
                ->where('all_clarks.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_clarks','stores_log.All_part_id','=','all_clarks.id')
                ->where('all_clarks.part_id','=',$partId)
                ->where('all_clarks.source_id','=',$sourceId)
                ->where('all_clarks.status_id','=',$statusId)
                ->where('all_clarks.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }
        else if($type == 5){
            return $stores->each(function ($item) use ($partId , $sourceId,$statusId,$qualityId,$type){
                // $storeClass = 'App\Models\\'.ucfirst($item->table_name);
                $item->storepart = DB::table($item->table_name)
                ->select($item->table_name.'.*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_equips','stores_log.All_part_id','=','all_equips.id')
                ->where('all_equips.part_id','=',$partId)
                ->where('all_equips.source_id','=',$sourceId)
                ->where('all_equips.status_id','=',$statusId)
                ->where('all_equips.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->get();

                $item->storepartCount = DB::table($item->table_name)
                ->select('*')
                ->join('stores_log',$item->table_name.'.store_log_id','=','stores_log.id')
                ->join('all_equips','stores_log.All_part_id','=','all_equips.id')
                ->where('all_equips.part_id','=',$partId)
                ->where('all_equips.source_id','=',$sourceId)
                ->where('all_equips.status_id','=',$statusId)
                ->where('all_equips.quality_id','=',$qualityId)
                ->where('stores_log.status','=',3)
                ->where($item->table_name.'.type_id','=',$type)
                ->sum($item->table_name.'.amount');


            });
        }




    }

//   public function CardInfo(Request $request){

//         $partData = array();
//         $allpartId = $request->allpartId;


//         $partData['allpart'] =$allpart = AllPart::where('id',$allpartId)->with(['part'=>function($m){
//             $m->with(['sub_group' =>function($q){
//                     $q->with('group')->get();
//             }]);
//             $m->with(['part_details' => function($q){
//                     $q->with('part_spec')->get();
//             }]);
//             $m->with('part_images');
//             $m->with(['part_models' => function($q){
//                 $q->with(['series'=>function($q1){
//                     $q1->with(['model'=>function($q2){
//                         $q2->with('brand')->with('brand_type')->get();
//                     }])->get();
//                 }])->get();
//             }]);

//             $m->with(['related_parts'=>function($q){
//                     $q->with(['part'=>function($q1){
//                         $q1->with('part_images')->get();
//                     }])->get();
//                 }]);
//             $m->with('all_parts');
//         }])->get();


//           return $partData;
//     }



  public function CardInfo1(Request $request){

        $partData = array();
        $allpartId = $request->allpartId;


        $allpart = AllPart::where('id',$allpartId)->with(['part'=>function($m){
            $m->with(['sub_group' =>function($q){
                    $q->with('group')->get();
            }]);
            $m->with(['part_details' => function($q){
                    $q->with('part_spec')->with('mesure_unit')->get();
            }]);
            $m->with(['part_numbers' => function($q){
                $q->with('supplier')->get();
            }]);
            $m->with('part_images');
            $m->with(['part_models' => function($q){
                $q->with(['series'=>function($q1){
                    $q1->with(['model'=>function($q2){
                        $q2->with('brand')->with('brand_type')->get();
                    }])->get();
                }])->get();
            }]);

            $m->with(['related_parts'=>function($q){
                    $q->with(['part'=>function($q1){
                        $q1->with('part_images')->get();
                    }])->get();
                }]);
            $m->with(['all_parts'=>function($q){
                $q->with('status')->with('source')->with('part_quality')->get();

            }]);
        }])->with('status')->with('source')->with('part_quality')->get();


        $allpart[0]['price'] = SalePricing::where('part_id',$allpart[0]->part_id)->where('source_id',$allpart[0]->source_id)->where('status_id',$allpart[0]->status_id)->where('quality_id',$allpart[0]->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();

        $allpart[0]['stores'] =  $this->PartInStoresCount($allpart[0]->part_id,$allpart[0]->source_id,$allpart[0]->status_id,$allpart[0]->quality_id,1);

        $allpart[0]->part->all_parts->map(function($q) use($allpart){
            // if($q->id != $allpart[0]->id && $q->source_id != $allpart[0]->source_id && $q->status_id != $allpart[0]->status_id && $q->quality_id != $allpart[0]->quality_id){
                $q['rprice'] = SalePricing::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();
                $q['stock'] = $this->PartInStoresCount($q->part_id,$q->source_id,$q->status_id,$q->quality_id,1);
            // }else{
            //     $q['rprice'] = [];
            //     $q['stock'] = [];
            // }

        });

        // return $allpart[0]->part->all_parts->unique('source_id')->all();
        $partData['allpart'] =$allpart;


          return $partData;
}

  public function CardInfo(Request $request){

        $partData = array();
        $allpartId = $request->allpartId;
        $partId = $request->partId;
        $allpart='';


        if($allpartId){

            $allpart = AllPart::where('id',$allpartId)->with(['part'=>function($m){
                $m->with(['sub_group' =>function($q){
                        $q->with('group')->get();
                }]);
                $m->with(['part_details' => function($q){
                        $q->with('part_spec')->with('mesure_unit')->get();
                }]);
                $m->with(['part_numbers' => function($q){
                    $q->with('supplier')->get();
                }]);
                $m->with('part_images');
                $m->with(['part_models' => function($q){
                    $q->with(['series'=>function($q1){
                        $q1->with(['model'=>function($q2){
                            $q2->with('brand')->with('brand_type')->get();
                        }])->get();
                    }])->get();
                }]);

                $m->with(['related_parts'=>function($q){
                        $q->with(['part'=>function($q1){
                            $q1->with('part_images')->get();
                        }])->get();
                    }]);
                $m->with(['all_parts'=>function($q){
                    $q->with('status')->with('source')->with('part_quality')->get();

                }]);
                }])->with('status')->with('source')->with('part_quality')
            ->get();


            $allpart[0]['price'] = SalePricing::where('part_id',$allpart[0]->part_id)->where('source_id',$allpart[0]->source_id)->where('status_id',$allpart[0]->status_id)->where('quality_id',$allpart[0]->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();

            $allpart[0]['stores'] =  $this->PartInStoresCount($allpart[0]->part_id,$allpart[0]->source_id,$allpart[0]->status_id,$allpart[0]->quality_id,1);

            $allpart[0]->part->all_parts->map(function($q) use($allpart){
                $q['rprice'] = SalePricing::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();
                $q['stock'] = $this->PartInStoresCount($q->part_id,$q->source_id,$q->status_id,$q->quality_id,1);
            });
        }else{

            $allpart = AllPart::where('part_id',$partId)->with(['part'=>function($m){
                $m->with(['sub_group' =>function($q){
                        $q->with('group')->get();
                }]);
                $m->with(['part_details' => function($q){
                        $q->with('part_spec')->with('mesure_unit')->get();
                }]);
                $m->with(['part_numbers' => function($q){
                    $q->with('supplier')->get();
                }]);
                $m->with('part_images');
                $m->with(['part_models' => function($q){
                    $q->with(['series'=>function($q1){
                        $q1->with(['model'=>function($q2){
                            $q2->with('brand')->with('brand_type')->get();
                        }])->get();
                    }])->get();
                }]);

                $m->with(['related_parts'=>function($q){
                        $q->with(['part'=>function($q1){
                            $q1->with('part_images')->get();
                        }])->get();
                    }]);
                $m->with(['all_parts'=>function($q){
                    $q->with('status')->with('source')->with('part_quality')->get();

                }]);
                }])->with('status')->with('source')->with('part_quality')
            ->first();

            if ($allpart){

                $allpart['price'] = SalePricing::where('part_id',$allpart->part_id)->where('source_id',$allpart->source_id)->where('status_id',$allpart->status_id)->where('quality_id',$allpart->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();

                $allpart['stores'] =  $this->PartInStoresCount($allpart->part_id,$allpart->source_id,$allpart->status_id,$allpart->quality_id,1);

                $allpart->part->all_parts->map(function($q) use($allpart){
                    $q['rprice'] = SalePricing::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->where('type_id','1')->where('to',null)->with('sale_type')->orderBy('price','DESC')->get();
                    $q['stock'] = $this->PartInStoresCount($q->part_id,$q->source_id,$q->status_id,$q->quality_id,1);
                });
            }else{
                $allpart['part'] = part::where('id',$partId)->with(['sub_group' =>function($q){
                            $q->with('group')->get();
                    }])->with(['part_details' => function($q){
                            $q->with('part_spec')->with('mesure_unit')->get();
                    }])->with(['part_numbers' => function($q){
                        $q->with('supplier')->get();
                    }])->with('part_images')->with(['part_models' => function($q){
                        $q->with(['series'=>function($q1){
                            $q1->with(['model'=>function($q2){
                                $q2->with('brand')->with('brand_type')->get();
                            }])->get();
                        }])->get();
                    }])->with(['related_parts'=>function($q){
                            $q->with(['part'=>function($q1){
                                $q1->with('part_images')->get();
                            }])->get();
                        }])->with(['all_parts'=>function($q){
                        $q->with('status')->with('source')->with('part_quality')->get();

                    }])->first();
                    // return $allpart;
                    $allpart['price'] =[];
                    $allpart['stores'] =[];
                    $allpart['price'] =[];
                    $allpart['part']['all_parts'] =[];
                    $allpart['part']['status'] =[];
                    $allpart['part']['source'] =[];
                    $allpart['part']['part_quality'] =[];
            }


        }
        $partData['allpart'] =$allpart;
        return $partData;
}

    public function saveClientPrice(Request $request){

         if($request->client){
            $quote = new Quote();
            $quote->name =Carbon::now();
            $quote->date =Carbon::now();
            $quote->client_id =$request->client;
            $quote->store_id =$request->storeId;
            $quote->price_without_tax =$request->subtotal;
            $quote->tax_amount =$request->taxval;
            $quote->save();

            $inv_items = $request->items_part;
            for ($i=0; $i < count($inv_items) ; $i++) {

                $item = explode ("-", $inv_items[$i]) ;
                $part_id = $item[0];
                $source_id = $item[1];
                $status_id = $item[2];
                $quality_id = $item[3];
                $type_id = $item[4];
                $amount = $request->itemAmount[$i];
                $itemPrice = $request->itemPrice[$i];
                
                $QuoteItem = new QuoteItem();
                $QuoteItem->date = Carbon::now();

                $QuoteItem->part_id = $part_id;
                $QuoteItem->amount = $amount;
                $QuoteItem->selected_price = $itemPrice;
                $QuoteItem->source_id = $source_id;
                $QuoteItem->status_id = $status_id;
                $QuoteItem->quality_id = $quality_id;
                $QuoteItem->part_type_id = $type_id;
                $QuoteItem->quote_id = $quote->id;
                $QuoteItem->sale_type = $request->pricetype[$i];
                $QuoteItem->save();
            }

            return 'Successfully Added';
        }else{
            return 'No Client Selected';
        }



    }
    
    public function getquoteData($id,$storeId){
        $quote= Quote::where('id',$id)->with(['quoteItems'=>function($q){
            $source = $q->with('source')->get();
            $q->with('status')->get();
            $q->with('part_quality')->get();
            $q->with('pricing_type')->get();
            $q->where('part_type_id','1')->with('part')->get();
        }])->get();
        
        $quote[0]['quoteItems']->map(function ($q) use ($storeId) {
            if($q->part_type_id == 1){
                $q['allparts'] = AllPart::where('part_id',$q->part_id)->where('source_id',$q->source_id)->where('status_id',$q->status_id)->where('quality_id',$q->quality_id)->get();    
            }
            
        });
        
        
        return $quote;
    }
    public function saveclientinvoiceprice(Request $request){
        //return $request;
        $invoice = new Invoice();

        $invoice->name = Carbon::now();
        $invoice->casher_id = Auth::user()->id;
        $invoice->discount = $request->discPrice;
        $invoice->actual_price = $request->totalPrice;
        $invoice->client_id  = $request->clientId;
        $invoice->company_id ="10";
        $invoice->store_id = $request->storeId;
        $invoice->price_without_tax = $request->subtotalPrice;
        $invoice->tax_amount = $request->taxPrice;
        $invoice->paied = $request->paiedPrice;
        $invoice->date = Carbon::now();
        $invoice->save();

        /// invoice Tax /////////////////
        // if(isset($request->taxes)){
        //     for ($i=0; $i < count($request->taxes) ; $i++) {
        //         $invTax = new InvoicesTax();
        //         $invTax->invoice_id =$invoice->id ;
        //         $tax= Tax::where('value',$request->taxes[$i])->get();
        //         $invTax->tax_id=$tax[0]->id;
        //         $invTax->save();

        //     }
        // }



        //////////////////// Only Part//////////////////////////
        $inv_items = $request->part_id;
        for ($i=0; $i < count($inv_items) ; $i++) {

            
            $part_id = $inv_items[$i];
            $source_id = $request->source_id[$i];
            $status_id = $request->status_id[$i];
            $quality_id = $request->quality_id[$i];
            $type_id = $request->type_id[$i];
            $amount = $request->itemamount[$i];

            $invoiceItems = new InvoiceItem();
            $invoiceItems->date = Carbon::now();

            $invoiceItems->part_id = $part_id;
            $invoiceItems->amount = $amount;
            $invoiceItems->source_id = $source_id;
            $invoiceItems->status_id = $status_id;
            $invoiceItems->quality_id = $quality_id;
            $invoiceItems->part_type_id = $type_id;
            $invoiceItems->invoice_id = $invoice->id;
            $invoiceItems->sale_type = $request->saletype;
            $invoiceItems->save();


            //// remove from store ///////////////////

            $allparts = AllPart::where('remain_amount','>',0)->where('part_id',$part_id)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->orderBy('id', 'ASC')->get();

            $store = Store::where('id',$request->storeId)->get();
            $store_id = $store[0]->id;
            $store_name = $store[0]->name;
            $store_table_name = $store[0]->table_name;

            try {

                DB::table($store_table_name)->where('part_id', $part_id)->where('supplier_order_id', $allparts[0]->order_supplier_id)->where('type_id', 1)->decrement('amount', $amount);
            } catch (\Throwable $th) {
                //throw $th;
            }

            /////////////////////////////////////


            ////// remove from all parts ////////

            AllPart::where('remain_amount','>',0)->where('part_id',$part_id)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->orderBy('id', 'ASC')->decrement('remain_amount',$amount);

            //////////////////////////////////////
            ////// remove from Sectios ////////
             try {

                DB::table('store_section')->where('part_id', $part_id)->where('supplier_order_id', $allparts[0]->order_supplier_id)->where('type_id', 1)->where('source_id',$source_id)->where('status_id',$status_id)->where('quality_id',$quality_id)->decrement('amount', $amount);
            } catch (\Throwable $th) {
                //throw $th;
            }

        }
        /////////////////////adel///////////
        $store=Store::where('id',$request->storeId)->first();
        $cli = Client::where('id',$request->clientId)->get();
        $total = MoneySafe::where('store_id',$request->storeId)->latest()->first();
        if (isset($total)) {
            MoneySafe::create([
                'notes' =>'مبلغ فاتورة بيع رقم'.' '.$invoice->id.' '.' من عميل '.' '.$cli[0]->name.' '.$store->name,

                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->paiedPrice,
                'total' => $total->total + $request->paiedPrice,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->storeId
            ]);
        } else {
            MoneySafe::create([
                'notes' =>'مبلغ فاتورة بيع رقم'.' '.$invoice->id.' '.' من عميل '.' '.$cli[0]->name.' '.$store->name,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->paiedPrice,
                'total' => $request->paiedPrice,
                'type_money'=>'0',
                'user_id'=>Auth::user()->id,
                'store_id'=>$request->storeId

            ]);
        }

   /// delete quote $request->quoteId
        Quote::find($request->quoteId)->delete();
   
        return redirect()->to('printInvoice/'.$invoice->id);
    }
}
