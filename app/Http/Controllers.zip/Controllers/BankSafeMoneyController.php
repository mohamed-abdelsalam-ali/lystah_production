<?php

namespace App\Http\Controllers;

use App\Models\BankSafeMoney;
use App\Models\BankType;
use App\Models\CurrencyType;
use App\Models\MoneySafe;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BankSafeMoneyController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $safeMoney = BankSafeMoney::with('user')->with('store')->with('currency')->with('bank_type')->get();
        // return $safeMoney;
        $all_curencys = CurrencyType::all();
        $all_stores = Store::all();
        $bank_types = BankType::all();

        $current_balance = $safeMoney->last();
        if (isset($current_balance->total)) {
            $current_balance = $safeMoney->last()->total;
            return view('money_safe.bank_safe_money', compact('bank_types', 'safeMoney', 'current_balance', 'all_stores', 'all_curencys'));
        } else {
            $current_balance = 0;
            return view('money_safe.bank_safe_money', compact('bank_types', 'safeMoney', 'current_balance', 'all_stores', 'all_curencys'));
        }
    }
    public function add_money_bank(Request $request)
    {
        // return $request;
        $currency_id = $request->currency_id;

        $all_currency_types = CurrencyType::with(['currencies' => function ($query) use ($currency_id) {
            return $query->where('to', null)->where('currency_id', $currency_id);
        }])->where('id', $currency_id)->get();

        $total = BankSafeMoney::all()->last();
        if (isset($total)) {
            $bank_safe = BankSafeMoney::create([
                'notes' => $request->notes,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->money *  $all_currency_types[0]->currencies[0]->value,
                'total' => $total->total + ($request->money *  $all_currency_types[0]->currencies[0]->value),
                'type_money' => '0',
                'user_id' => Auth::user()->id,
                'store_id' => null,
                'money_currency' => $request->money,
                'currency_id' => $currency_id,
                'bank_type_id'=>$request->bank_type_id
            ]);
        } else {
            $bank_safe = BankSafeMoney::create([
                'notes' => $request->notes,
                'date' => date('Y-m-d'),
                'flag' => 1,
                'money' => $request->money *  $all_currency_types[0]->currencies[0]->value,
                'total' => $request->money *  $all_currency_types[0]->currencies[0]->value,
                'type_money' => '0',
                'user_id' => Auth::user()->id,
                'store_id' => null,
                'money_currency' => $request->money,
                'currency_id' => $currency_id,
                'bank_type_id'=>$request->bank_type_id



            ]);
        }
        if ($request->file('img_path')) {
            $var = date_create();
            $time = date_format($var, 'YmdHis');
            $image_user = $time . '-'  . $request->img_path->getClientOriginalName();
            $request->img_path->move(public_path('notes_safe_money'), $image_user);
            $bank_safe->update([
                'img_path' => $image_user

            ]);
        }
        session()->flash("success", "تم أضافة المبلغ للخزنة بنجاح");
        return redirect()->back();
    }
    public function add_other_bank(Request $request)
    {
        // return $request;-
        $currency_id = $request->currency_id;

        $all_currency_types = CurrencyType::with(['currencies' => function ($query) use ($currency_id) {
            return $query->where('to', null)->where('currency_id', $currency_id);
        }])->where('id', $currency_id)->get();
        $total = BankSafeMoney::all()->last();
        if (isset($total)) {
            if ($total->total >= ($request->money * $all_currency_types[0]->currencies[0]->value)) {
                $bank_safe= BankSafeMoney::create([
                    'notes' => $request->notes,
                    'date' => date('Y-m-d'),
                    'flag' => 2,
                    'money' => $request->money * $all_currency_types[0]->currencies[0]->value,
                    'total' => $total->total - ($request->money * $all_currency_types[0]->currencies[0]->value),
                    'type_money' => '1',
                    'user_id' => Auth::user()->id,
                    'store_id' => null,
                    'money_currency' => $request->money,
                    'currency_id' => $currency_id,
                    'bank_type_id'=>$request->bank_type_id
                ]);
                if ($request->file('img_path')) {
                    $var = date_create();
                    $time = date_format($var, 'YmdHis');
                    $image_user = $time . '-'  . $request->img_path->getClientOriginalName();
                    $request->img_path->move(public_path('notes_safe_money'), $image_user);
                    $bank_safe->update([
                        'img_path' => $image_user

                    ]);
                }
                session()->flash("success", "تم صرف المبلغ  بنجاح");
                return redirect()->back();
            } else {
                session()->flash("success", "  المبلغ غير كافي في الخزنة");
                return redirect()->back();
            }
        } else {

            session()->flash("success", "   لا يوجد رصيد في الخزنة   ");
            return redirect()->back();
        }
    }
    public function show_safe_bank_Money_month($month)
    {
        $safeMoney = BankSafeMoney::whereDate('date', $month)->with('user')->with('store')->with('currency')->get();

        return $safeMoney;
    }
    public function money_bank_send_store(Request $request)
    {
        // return $request;
        $total = BankSafeMoney::all()->last();
        $currency_id = $request->currency_id;
        $all_currency_types = CurrencyType::with(['currencies' => function ($query) use ($currency_id) {
            return $query->where('to', null)->where('currency_id', $currency_id);
        }])->where('id', $currency_id)->get();
        if (isset($total)) {
            if ($total->total >= ($request->money * $all_currency_types[0]->currencies[0]->value)) {
                $bank_safe= BankSafeMoney::create([
                    'notes' => $request->notes,
                    'date' => date('Y-m-d'),
                    'flag' => 3,
                    'money' => $request->money * $all_currency_types[0]->currencies[0]->value,
                    'total' => $total->total - ($request->money * $all_currency_types[0]->currencies[0]->value),
                    'type_money' => '1',
                    'user_id' => Auth::user()->id,
                    'store_id' => $request->to_store,
                    'money_currency' => $request->money,
                    'currency_id' => $currency_id,
                    'bank_type_id'=>$request->bank_type_id,

                ]);
                $total_to_store = MoneySafe::where('store_id', $request->to_store)->latest()->first();

                if (isset($total_to_store)) {
                   $safe= MoneySafe::create([
                        'notes' => $request->notes,
                        'date' => date('Y-m-d'),
                        'flag' => 1,
                        'money' => $request->money * $all_currency_types[0]->currencies[0]->value,
                        'total' => $total_to_store->total + ($request->money * $all_currency_types[0]->currencies[0]->value),
                        'type_money' => '0',
                        'user_id' => Auth::user()->id,
                        'store_id' => $request->to_store,
                        'note_id'=>4
                    ]);
                } else {
                    $safe=MoneySafe::create([
                        'notes' => $request->notes,
                        'date' => date('Y-m-d'),
                        'flag' => 1,
                        'money' => $request->money * $all_currency_types[0]->currencies[0]->value,
                        'total' => $request->money * $all_currency_types[0]->currencies[0]->value,
                        'type_money' => '0',
                        'user_id' => Auth::user()->id,
                        'store_id' => $request->to_store,
                        'note_id'=>4


                    ]);
                }
                if ($request->file('img_path')) {
                    $var = date_create();
                    $time = date_format($var, 'YmdHis');
                    $image_user = $time . '-'  . $request->img_path->getClientOriginalName();
                    $request->img_path->move(public_path('notes_safe_money'), $image_user);
                    $bank_safe->update([
                        'img_path' => $image_user

                    ]);
                    $safe->update([
                        'img_path' => $image_user

                    ]);
                }
                session()->flash("success", "تم صرف المبلغ  بنجاح");
                return redirect()->back();
            } else {
                session()->flash("success", "  المبلغ غير كافي في الخزنة");
                return redirect()->back();
            }
        } else {

            session()->flash("success", "   لا يوجد رصيد في الخزنة   ");
            return redirect()->back();
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
