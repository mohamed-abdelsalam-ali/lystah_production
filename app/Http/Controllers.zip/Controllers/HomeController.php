<?php

namespace App\Http\Controllers;

use App\Models\BuyTransaction;
use App\Models\OrderSupplier;
use App\Models\Invoice;
use App\Models\BankSafeMoney;

use DB;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $Buy_Transaction_Count= BuyTransaction::count('id');
        $Buy_Transaction_Total= OrderSupplier::with([
            'currency_type'=>function($query){
                return $query->with([
                   'currencies'=>function($q){
                       $q->where('to', '=', null) ; 
                       
                   }]); 
            
        }])->get();
              
        $sum_Buy_Total=$Buy_Transaction_Total->sum(function ($item) {
          return $item->total_price * $item->currency_type->currencies[0]->value;
        });
        
        
        $sell_Transaction_Count= Invoice::count('id');    
        $sell_Transaction_Total= Invoice::sum('actual_price');
        
        
        $BanksafeMoney = BankSafeMoney::get();
        $current_balance = $BanksafeMoney->last();
        return view('index',compact('Buy_Transaction_Count','sum_Buy_Total','sell_Transaction_Count','sell_Transaction_Total','current_balance'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Country $country)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Country $country)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy()
    {
        //
    }
   
}
