<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use App\Models\Client;
use App\Models\Supplierbank;
use Illuminate\Http\Request;

class SupplierController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $all_suplliers=Supplier::all();
        // return $all_suplliers;
        return view('supplier.index',compact('all_suplliers'));
    }

    public function Selectindex()
    {
        $all_suplliers=Supplier::all();
        return $all_suplliers;

    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // return $request;
        if ($request->hasfile('supplier_image')){
            $var = date_create();
            $time = date_format($var, 'YmdHis');
            $image_supplier = $time . '-' . $request->name . '-' . $request->supplier_image->getClientOriginalName();
            $request->supplier_image->move(public_path('supplier_images'), $image_supplier);
            Supplier::create([
                'name'=>$request->name,
                'desc'=>$request->desc,
                'rate'=>$request->rate,
                'address'=>$request->address,
                'email'=>$request->email,
                'tel01'=>$request->tel01,
                'tel02'=>$request->tel02,
                'country'=>$request->country,
                'image'=>$image_supplier,


            ]);

        }else{
            Supplier::create([
                'name'=>$request->name,
                'desc'=>$request->desc,
                'rate'=>$request->rate,
                'address'=>$request->address,
                'email'=>$request->email,
                'tel01'=>$request->tel01,
                'tel02'=>$request->tel02,
                'country'=>$request->country,

            ]);

        }
        session()->flash("success", "تم الاضافة بنجاح");
        return redirect()->route('supplierindex.index');

    }

    /**
     * Display the specified resource.
     */
    public function show(Supplier $supplier)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Supplier $supplier)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        // return $request;
        $supplier=Supplier::where('id',$request->supplier_id)->first();
        // return $supplier;
        if ($request->hasfile('supplier_image')){
            if(isset($supplier->image))
            {
             $image_path = public_path() . '/supplier_images' . '/' . $supplier->image;
             unlink($image_path);

            }
            $var = date_create();
            $time = date_format($var, 'YmdHis');
            $image_supplier = $time . '-' . $request->name . '-' . $request->supplier_image->getClientOriginalName();
            $request->supplier_image->move(public_path('supplier_images'), $image_supplier);
            $supplier->update([
                'name'=>$request->name,
                'desc'=>$request->desc,
                'rate'=>$request->rate,
                'address'=>$request->address,
                'email'=>$request->email,
                'tel01'=>$request->tel01,
                'tel02'=>$request->tel02,
                'country'=>$request->country,
                'image'=>$image_supplier,

            ]);
        }else{
            $supplier->update([
                'name'=>$request->name,
                'desc'=>$request->desc,
                'rate'=>$request->rate,
                'address'=>$request->address,
                'email'=>$request->email,
                'tel01'=>$request->tel01,
                'tel02'=>$request->tel02,
                'country'=>$request->country,

            ]);

        }
        session()->flash("success", "تم التعديل بنجاح");
        return redirect()->route('supplierindex.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy( Request $request)
    {
        // return $request;
        $supplier=Supplier::where('id',$request->supplier_id)->first();
        // return $company;
        if(isset($supplier->image))
        {
            $image_path = public_path() . '/supplier_images' . '/' . $supplier->image;
            unlink($image_path);


        }
        $supplier->delete();
        session()->flash("success", "تم الحذف بنجاح");
        return redirect()->route('supplierindex.index');

    }
    public function show_account_bank($id)
    {
        $supplier=Supplier::where('id',$id)->first();
        $all_account_bank=Supplierbank::where('supplier_id',$id)->with('supplier')->get();
        // return $all_account_bank;
        return view('supplier.show_account_bank',compact('supplier','all_account_bank'));


    }


    public function use_Sup_As_Client(Request $request){
        // return $request->data;

        $supplier_id =$request->data;
        $supllier_data=Supplier::where('id','=',$supplier_id)->first();


        $client_id=Client::create([
            'name' => $supllier_data->name,
            'address' => $supllier_data->country,
            'tel01' => $supllier_data->tel01,
            'tel02' => $supllier_data->tel02,
            'national_no' => $supllier_data->national_no,
            'notes' => $supllier_data->desc,
            'email1' => $supllier_data->email,
            'email2' => $supllier_data->email2,
            'sup_id' => $supplier_id,
            'client_raseed' => 0,
        ])->id;

        return $client_id;
    }

    public function check_Sup_As_Client(Request $request){
        // return $request->data;

        $supplier_id =$request->data;
        $client=Client::where('sup_id','=',$supplier_id)->get();




        return $client;
    }
    
     public function use_client_as_suplier(Request $request){
        // return $request->data;

        $client_id =$request->data;
        $client_data=Client::where('id','=',$client_id)->first();


        $sup_id=Supplier::create([
            
            'name'=> $client_data->name,
            'desc'=>$client_data->notes,
            'address'=>$client_data->address,
            'email'=>$client_data->email1,
            'tel01'=>$client_data->tel01,
            'tel02'=>$client_data->tel02,
        ])->id;
        
        Client::where('id','=',$client_id)->update(['sup_id'=>$sup_id]);
        return $sup_id;
        
    }
    public function get_all_sup(){
         return Supplier::all();
    }
    
}
