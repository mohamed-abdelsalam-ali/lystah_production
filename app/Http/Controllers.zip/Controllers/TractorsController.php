<?php

namespace App\Http\Controllers;

use App\Models\Tractor;
use App\Models\TractorNumber;
use App\Models\RelatedTractor;
use App\Models\TractorSpec;
use App\Models\Series;
use App\Models\TractorImage;
use App\Models\EfragImage;
use App\Models\TractorDetail;
use App\Models\BrandType;
use App\Models\Brand;
use App\Models\Model;
use App\Models\BuyTransaction;
use App\Models\OrderSupplier;
use App\Models\Replyorder;
use App\Models\AllTractor;
use App\Models\Store;
use App\Models\StoresLog;
use App\Models\InvoiceImage;

use File;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use DataTables;
use Carbon\Carbon;
class TractorsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function indexWithID(Tractor $tractorId)
    {

        $all_tractor = AllTractor::where('part_id' , $tractorId->id)->get();
        $tractor=Tractor::where('id' , $tractorId->id)
        ->with(['all_tractors'=>function($query){
                return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['replyorders'=>function($query2){
                        return $query2->get();
                }])->get();
                }]);
            }])

        ->with(['tractor_details'=>function($query3){
            return $query3->with(['tractor_spec'=>function($query4){
                return $query4->get();
            }])->get();
        }])
        ->with(['series'=> function($query8){
            return $query8->with(['model'=>function($query9){
                return $query9->with('brand')->with('brand_type')->get();
            }])->get();
        }])
        ->with('tractor_images')
        ->with('efrag_images')
        ->with(['invoice_images'=>function($query5){
            return $query5->where('part_type_id' , '3')->get();
        }])
        ->with(['related_tractors'=>function($query6){
            return $query6->with(['parts'=>function($query7){
                return $query7->get();
            }])->get();
        }])
        ->get();
        $store_log = StoresLog::where('All_part_id' , $all_tractor[0]->id )->where( 'type_id' , '3')->get();
        return([$tractor,$store_log]);

    }

    public function indexWithRequest(Request $request)
    {
        if ($request->ajax()) {
            $data = Tractor::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('name',function($row){
                    return $row->name ;
                })
                ->addColumn('tractorNumbers',function($row){
                    return isset($row->tractor_number) ? $row->tractor_number : '--';


                })
                ->addColumn('tractorSeries',function($row){
                    $tractorSeries= Series::where('id',$row->model_id)->get();
                    foreach ($tractorSeries as $key => $value) {
                        return isset($value->name) ? $value->name : '--';
                    }
                })
                ->addColumn('tractorBrand',function($row){
                    $tractorSeries= Series::where('id',$row->model_id)->get();
                    foreach ($tractorSeries as $key => $value) {
                        return isset($value->model->name) ? $value->model->name : '--';
                    }
                })

                ->addColumn('Image',function($row){
                    $tractorImage = TractorImage::where('tractor_id',$row->id)->get();
                    $html="";
                    foreach ($tractorImage as $key => $value) {
                        $html = $html . '<img class="rounded-circle header-profile-user" src="assets/tractor_images/'. $value->url.'" alt="Emara">';
                    }
                    return $html;
                })
                ->addColumn('efragImage',function($row){
                    $efragImage = EfragImage::where('tractor_id',$row->id)->get();
                    $html="";
                    foreach ($efragImage as $key => $value) {
                        $html = $html . '<img class="rounded-circle header-profile-user" src="assets/efrag_images/'. $value->image_name.'" alt="Emara">';
                    }
                    return $html;
                })

                ->addColumn('action', function($row){

                    $btn = '<a  data-bs-toggle="modal"  tractor_id_value="'.$row->id.'"  data-bs-target="#editTractor"
                    data-toggle="tooltip" data-original-title="Edit" class="btn btn-primary btn-sm editTractorB"><i class="ri-edit-line editTractorButton"></i></a>';
                    $btn = $btn.' <form action="'.route("tractor.destroy",$row->id).'" method="POST">'
                            . csrf_field()
                            . method_field('DELETE')
                            .'<input type="submit" value="Delete" class= "btn btn-danger">'.
                            '</form>';
                    $btn = $btn.'<a href="'.route("tractor.print",$row->id ).'"
                    class="btn btn-success btn-sm printTractor">Print<i class="ri-print-line"></i></a>';
                    return $btn;
                })
                ->rawColumns(['name','tractorNumbers','tractorSeries', 'tractorBrand','Image','efragImage','action'])
                ->make(true);
        }
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        Tractor::create($request->all());
        $tractor_id=Tractor::max('id');

        if(isset($request->specs)){
            for ($i=0; $i < count($request->specs) ; $i++) {
                if($request->specs[$i] != null){
                    $specs = new TractorSpec();
                    $specs->name = $request->specs[$i];
                    $specs->general_flag = $tractor_id;
                    $specs->save();
                    $specDetail = new TractorDetail();
                    $specDetail->Tractorpecs_id = $specs->id;
                    $specDetail->tractor_id = $tractor_id;
                    if(isset($request->specsval)){
                        $specDetail->value = $request->specsval[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecs)){
            for ($j=0; $j < count($request->oldspecsval) ; $j++) {
                if($request->oldspecsval[$j] != null){
                    TractorDetail::create(['Tractorpecs_id'=> $request->oldSpecs[$j] ,'tractor_id'=> $tractor_id ,'value' => $request->oldspecsval[$j]]);
                }else{
                    continue;
                }

            }
        }
        if(isset($request->relatedPart)){
            for ($i=0; $i < count($request->relatedPart) ; $i++) {
                RelatedTractor::create(['tractor_id' => $tractor_id , 'sug_part_id' => $request->relatedPart[$i]]);
            }
        }
        if(isset($request->tractorImg)){
            for ($i=0; $i < count($request->tractorImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->tractorImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->tractorImg[$i]->extension() ;
                $request->tractorImg[$i]->move(public_path('assets/tractor_images'), $imageName);
                TractorImage::create(['tractor_id' => $tractor_id , 'name' => $namewithoutchar, 'url' => $imageName]);

            }
        }

        if(isset($request->releaseImg)){
            for ($i=0; $i < count($request->releaseImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->releaseImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->releaseImg[$i]->extension() ;
                $request->releaseImg[$i]->move(public_path('assets/efrag_images'), $imageName);
                EfragImage::create(['tractor_id' => $tractor_id ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }



        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg)){
            for ($i=0; $i < count($request->invoiceImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg[$i]->extension() ;
                $request->invoiceImg[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $tractor_id ,'name' => $namewithoutchar,  'image_name' => $imageName , 'part_type_id' =>'3' ]);
            }
        }
        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplier_id,'status' =>'0' , 'container_size'=> $request->container_size , 'total_price' => $request->price ,'deliver_date'=> $request->deliverydate , 'bank_account' => $request->bank_account, 'currency_id' => $request->currency_id ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $tractor_id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'3' , 'price' => $request->price, 'source_id' => $request->source_id ,'quality_id' => $request->quality_id, 'status_id' => $request->status_id ]);
        AllTractor::create(['part_id' => $tractor_id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id , 'status_id' => $request->status_id , 'buy_price' => $request->price , 'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id , 'lastupdate' => Carbon::now()]);
        $all_tractor_id = AllTractor::max('id');
        StoresLog::create(['All_part_id' => $all_tractor_id , 'store_action_id' => '3' , 'store_id' => $request->store_id , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '3']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $tractor_id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='3'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }
        return back()->with('success','You Have Successfully Saved Tractor.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Tractor $tractor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Tractor $tractor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Tractor $tractor)
    {
         $imgURLsInp = explode(',', $request->imgURLsInp[0]) ;
         $imgURLsInpInvoice = explode(',', $request->imgURLsInpInvoice[0]) ;
         $imgURLsInpEfrag = explode(',', $request->imgURLsInpEfrag[0]) ;
// return $request->imgURLsInpEfrag;
        for($i = 0 ; $i< count($imgURLsInpInvoice) ; $i++){
            if($imgURLsInpInvoice[$i] != null){
                $tractor->invoice_images()->where('image_name', $imgURLsInpInvoice[$i])->delete();
            }
        }

        for($i = 0 ; $i< count($imgURLsInpEfrag) ; $i++){
            if($imgURLsInpEfrag[$i] != null){
                $tractor->efrag_images()->where('image_name', $imgURLsInpEfrag[$i])->delete();
            }
        }

        for($i = 0 ; $i< count($imgURLsInp) ; $i++){
            if($imgURLsInp[$i] != null){
                $tractor->tractor_images()->where('url', $imgURLsInp[$i])->delete();
            }
        }

        $relatedTractor= RelatedTractor::where('tractor_id' ,$tractor->id);
        if(isset($relatedTractor)){
            $relatedTractor->delete();
        }

        $tractor->tractor_details()->delete();
        $tractor_specs= Tractorspec::where('general_flag' , $tractor->id)->get();
        if(count($tractor_specs)>0){
            $tractor_specs->each->delete();
        }

        $all_tractor = $tractor->all_tractors()->first();
        if(isset($all_tractor)){
            $order_supplier_id = $all_tractor->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_tractor->id)->where('type_id' , '3')->first();
        }

        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();

            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $tractor->id)->where('type_id' , '3')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_tractor)){
            AllTractor::find($all_tractor->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $tractor->id)->where('part_type_id' , '3')->first();
        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        $tractor->update(['name' => $request->name_edit , 'name_en' => $request->name_en_edit , 'fronttire' => $request->fronttire_edit , 'reartire' => $request->reartire_edit , 'gear_box' => $request->gear_box_edit, 'hours' => $request->hours_edit, 'power' => $request->power_edit , 'year' => $request->year_edit , 'color' => $request->color_edit , 'colotank_capacityr' => $request->tank_capacity_edit , 'discs' => $request->discs_edit , 'tractor_number' => $request->tractor_number_edit ,'model_id' => $request->model_id_edit ,'desc' => $request->desc_edit , 'drive' => $request->drive_edit , 'fronttirestatus' => $request->fronttirestatus_edit , 'reartirestatus' => $request->reartirestatus_edit , 'motornumber' => $request->motornumber_edit , 'serivcedate' => $request-> serivcedate_edit ]);

        if(isset($request->specsEdit)){
            for ($i=0; $i < count($request->specsEdit) ; $i++) {
                if($request->specsEdit[$i] != null){
                    $specs = new TractorSpec();
                    $specs->name = $request->specsEdit[$i];
                    $specs->general_flag = $tractor->id;
                    $specs->save();
                    $specDetail = new TractorDetail();
                    $specDetail->Tractorpecs_id = $specs->id;
                    $specDetail->tractor_id = $tractor->id;
                    if(isset($request->specsvalEdit)){
                        $specDetail->value = $request->specsvalEdit[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecsEdit)){
            for ($j=0; $j < count($request->oldSpecsEdit) ; $j++) {
                if($request->oldSpecsEdit[$j] != null){
                    TractorDetail::create(['Tractorpecs_id'=> $request->oldSpecsEdit[$j] ,'tractor_id'=> $tractor->id ,'value' => $request->oldspecsvalEdit[$j]]);
                }else{
                    continue;
                }
            }
        }
        if(isset($request->relatedPartEdit)){
            for ($i=0; $i < count($request->relatedPartEdit) ; $i++) {
                RelatedTractor::create(['tractor_id' => $tractor->id , 'sug_part_id' => $request->relatedPartEdit[$i]]);
            }
        }
        if(isset($request->tractorImg_edit)){
            for ($i=0; $i < count($request->tractorImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->tractorImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->tractorImg_edit[$i]->extension() ;
                $request->tractorImg_edit[$i]->move(public_path('assets/tractor_images'), $imageName);
                TractorImage::create(['tractor_id' => $tractor->id , 'name' => $namewithoutchar, 'url' => $imageName]);

            }
        }

        if(isset($request->releaseImg_edit)){
            for ($i=0; $i < count($request->releaseImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->releaseImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->releaseImg_edit[$i]->extension() ;
                $request->releaseImg_edit[$i]->move(public_path('assets/efrag_images'), $imageName);
                EfragImage::create(['tractor_id' => $tractor->id ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }
        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg_edit)){
            for ($i=0; $i < count($request->invoiceImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg_edit[$i]->extension() ;
                $request->invoiceImg_edit[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $tractor->id ,'part_type_id' => '3' ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }
        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplier_id_edit,'status' =>'0' , 'container_size'=> $request->container_size_edit , 'total_price' => $request->price_edit ,'deliver_date'=> $request->deliverydate_edit , 'bank_account' => $request->bank_account_edit, 'currency_id' => $request->currency_id_edit ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $tractor->id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'3' , 'price' => $request->price_edit, 'source_id' => $request->source_id_edit ,'quality_id' => $request->quality_id_edit, 'status_id' => $request->status_id_edit ]);
        AllTractor::create(['part_id' => $tractor->id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id_edit , 'status_id' => $request->status_id_edit , 'buy_price' => $request->price_edit , 'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id_edit , 'lastupdate' => Carbon::now()]);
        $all_tractor_id = AllTractor::max('id');
        StoresLog::create(['All_part_id' => $all_tractor_id , 'store_action_id' => '3' , 'store_id' => $request->store_id_edit , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '3']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id_edit)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $tractor->id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='3'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }

        return back()->with('success','You Have Successfully Updated Tractor.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Tractor $tractor)
    {
        $image_name= InvoiceImage::where('part_id' , $tractor->id)->where('part_type_id' , '3')->get('image_name');

        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/invoice_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $invoice_image= InvoiceImage::where('part_id' , $tractor->id)->where('part_type_id' , '3')->get();
        if(isset($invoice_image)){
            $invoice_image->each->delete();
        }

        $image_name = $tractor->efrag_images()->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/efrag_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $tractor->efrag_images()->delete();
        $image_name = $tractor->tractor_images()->get('url');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/tractor_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $tractor->tractor_images()->delete();
        $relatedTractor= RelatedTractor::where('tractor_id' ,$tractor->id)->get();
        if(isset($relatedTractor)){
            $relatedTractor->each->delete();
        }

        $tractor->tractor_details()->delete();
        $tractor_specs= Tractorspec::where('general_flag' , $tractor->id)->get();
        if(count($tractor_specs)>0){
        $tractor_specs->each->delete();
            }
        $all_tractor = $tractor->all_tractors()->first();
        if(isset($all_tractor)){
            $order_supplier_id = $all_tractor->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_tractor->id)->where('type_id' , '3')->first();
        }
        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();

            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $tractor->id)->where('type_id' , '3')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_tractor)){
            AllTractor::find($all_tractor->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $tractor->id)->where('part_type_id' , '3')->first();
        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        Tractor::where('id' , $tractor->id)->delete();
        return back()->with('success','You Have Successfully Deleted Tractor.');
    }

    public function tractorspecs(){

        return TractorSpec::where('general_flag','0')->get();
    }

    public function tractorBrand(){
        $brandType = BrandType::all();
        $brand = Brand::all();
        return[$brandType , $brand];
    }

    public function tractormodel($brandId,$ttypeid){
        return Model::where('brand_id',$brandId)->where('type_id',$ttypeid)->get();
    }

    public function tractorseries($modelId){
        $series =  Series::where('model_id',$modelId)->with('model')->get();
        return $series;
    }

    public function printtractor($tractor_id){
        $tractor =  Tractor::where('id' , $tractor_id)

        ->with(['all_tractors'=>function($query){
            return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['buy_transaction'=>function($query2){
                        return $query2->get();
                }])->with('currency_type')
                    ->with('supplier')
                    ->get();
            }])
            ->with('source')
            ->with('status')
            ->with('part_quality')
            ->get();
        }])
        ->with(['tractor_details'=>function($query){
            return $query->with(['tractor_spec'=>function($query1){
                return $query1->get();
            }])->get();
        }])
        ->with(['series'=>function($query){
            return $query->with(['model'=>function($query1){
                    return $query1->with(['brand'=>function($query2){
                        return $query2->get();
                }])->get();
            }]);
        }])
        ->with('drives')
        ->with('gearbox')
        ->with('rearTires')
        ->with('frontTires')
        ->with('tractor_images')->first();
        // return $tractor;
        return view("printTractor",compact("tractor"));
    }
}
