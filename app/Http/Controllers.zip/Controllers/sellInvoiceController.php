<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Yajra\DataTables\DataTables as DataTablesDataTables;
use Yajra\DataTables\Facades\DataTables as FacadesDataTables;

class sellInvoiceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return View('sell_invoice');

    }
   public function indexWithRequest(Request $request)
    {
        if ($request->ajax()) {
            $data = Invoice::with('client')->with('company')->with('store')->with('invoice_items')->get();
            // return $data;
            return FacadesDataTables::of($data)
                ->addIndexColumn()
                
                ->addColumn('Invoice_id', function ($row) {
                    return $row->id;
                })
                ->addColumn('date', function ($row) {
                    // $dd = explode(' ', $row->date);
                    // return $dd[0];
                    return $row->date;
                })
                ->addColumn('store_name', function ($row) {
                    return $row->store->name;
                })
                ->addColumn('client_name', function ($row) {
                    return $row->client->name;
                })
                    ->addColumn('casher', function ($row) {
                        $cashier = User::find($row->casher_id);
                        if( $cashier){
                          return  $cashier->username;
                        }else{
                            return 'old_inv';
                        }
                        
                        
                })
            
             ->addColumn('invoice_total', function ($row) {
                    return $row->actual_price;
                })
            ->addColumn('invoiceitemCount', function ($row) {
                    return count($row->invoice_items);
                })
                ->addColumn('action', function ($row) {
                    $btn = '<a href="printInvoice/' . $row->id . '" target="_blank" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editPost"><i class="mdi mdi-printer p-2"></i></a>';


                    return $btn;
                })
                ->rawColumns(['Invoice_id', 'date','client_name' ,'store_name','casher','invoice_total','invoiceitemCount','action'])
                ->make(true);
        }

        // $lastInvId = BuyTransaction::latest()->first()->id;
        return view('buy_invoice');
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Invoice $invoice)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Invoice $invoice)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Invoice $invoice)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Invoice $invoice)
    {
        //
    }
}
