<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Qayd;
use App\Models\Qayditem;
use App\Models\Qaydtype;
use App\Models\BranchTree;
use Illuminate\Support\Facades\DB;
class QaydController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $qayds=Qayd::with(['qaydtype'])->get();
        return view("qayd.index",compact("qayds"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view("qayd.create");
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd((count($request->request)-3)/4);=((count($request->request)-3)/4)
        // dd(count($request->request));
        //  dd($request->request);
        $qayd = Qayd::create([

            'qaydtypeid' =>   $request->qaydType,
            'date' => $request->dateQayd
        ]);
        $lastID=$qayd->id;
            for ($i=0; $i <count($request->note) ; $i++) {
                // print("branch".$i);
                $qayditem= Qayditem::create([

                    'qaydid' =>  $lastID,
                    'branchid' => $request->branch[$i],
                    'dayin'=> $request->dayn[$i],
                    'madin'=> $request->maden[$i],
                    'topic'=> $request->note[$i],
                    'date' => $request->dateQayd
                ]);
            }
            if ($qayditem) {
                return view('qayd.create')->with('success', 'تم الحفظ بنجاح');
            }
            return view('qayd.create')->with('error', 'لم يتم الحفظ ');
            
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $qayddetails=Qayditem::where('qaydid',$id)->with(['qayd', 'branch_tree'])->get();
        // dd($qayddetails->toArray());
        return view("qayd.show",compact("qayddetails"));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function search()
    {
        // $qayds=Qayd::with(['qaydtype'])->get();
        $accounts=[];
        $summadin=0;
        $sumdayin=0;
        return view("qayd.search",compact("accounts",'sumdayin','summadin'));
    }


    public function getallAccount(Request $request)
    {
        // $qayds=Qayd::with(['qaydtype'])->get();
        // qayditem.branchid = 29 And date >='2022-12-02' And date <= '2022-12-18'
        $accounts=Qayditem::where('branchid',$request->branchs)->
                  where('date','>=',$request->dateQaydfrom)->
                  where('date',"<=",$request->dateQaydto)->
                  with(['qayd', 'branch_tree'])->
                  get();
        $summadin=Qayditem::where('branchid',$request->branchs)->
                  where('date','>=',$request->dateQaydfrom)->
                  where('date',"<=",$request->dateQaydto)->
                  with(['qayd', 'branch_tree'])->
                  sum('madin');
        $sumdayin=Qayditem::where('branchid',$request->branchs)->
                  where('date','>=',$request->dateQaydfrom)->
                  where('date',"<=",$request->dateQaydto)->
                  with(['qayd', 'branch_tree'])->
                  sum('dayin');
        return view("qayd.search",compact("accounts","sumdayin","summadin"));
        // return $sum;
    }

    public function searchaccount()
    {
        // $qayds=Qayd::with(['qaydtype'])->get();
        $accounts=[];
        $summadin=0;
        $sumdayin=0;
        return view("qayd.searchaccount",compact("accounts",'sumdayin','summadin'));
    }
    public function accountstatement(Request $request)
    {
        // $qayds=Qayd::with(['qaydtype'])->get();
        // $accounts=[];
        // $summadin=0;
        // $sumdayin=0;
        // return view("qayd.searchaccount",compact("accounts",'sumdayin','summadin'));
        $accounts=Qayditem::where('branchid',$request->branchs)->
        where('date','>=',$request->dateQaydfrom)->
        where('date',"<=",$request->dateQaydto)->
        with(['qayd', 'branch_tree'])->get();
        // return $accounts;
        return view("qayd.searchaccount",compact("accounts"));




    }
    public function trialbalance()
    {
        $results=[];
        return view("qayd.trialbalance",compact("results"));

    }
    public function gettrialbalance(Request $request)
    {
        $results=Qayditem::where('date','>=',$request->dateQaydfrom)
                        ->where('date','<=',$request->dateQaydto)
                        ->with(['branch_tree'])
                        ->selectRaw("SUM(qayditem.dayin) as tdayin")
                        ->selectRaw("SUM(qayditem.madin) as tmadin")
                        ->selectRaw("qayditem.branchid")

                        ->groupBy("qayditem.branchid")
                        ->get();

        return view("qayd.trialbalance",compact("results"));


        // return $results;


    }
    public function test(){
        $results=Qayditem::where('date','>=','2022-01-21')
                        ->where('date','<=',now()->toDateString('Y-m-d') )
                        ->with(['branch_tree'])
                        ->selectRaw("SUM(qayditem.dayin) as tdayin")
                        ->selectRaw("SUM(qayditem.madin) as tmadin")
                        ->selectRaw("qayditem.branchid")

                        ->groupBy("qayditem.branchid")
                        ->get();

                        BranchTree::query()->update(['notes' => 0]);
        foreach($results as $result ) {
            $r=$result->tmadin -  $result->tdayin;
            if($r<0){
                $r*=-1;
                BranchTree::where('id', $result->branchid)->update(['notes' => $r]);
            }
            BranchTree::where('id', $result->branchid)->update(['notes' => $r]);

        }
        // return    $results ;
    }
}
