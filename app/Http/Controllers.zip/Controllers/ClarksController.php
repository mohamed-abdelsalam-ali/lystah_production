<?php

namespace App\Http\Controllers;

use App\Models\Clark;
use App\Models\ClarkSpec;
use App\Models\ClarkNumber;
use App\Models\RelatedClark;
use App\Models\Series;
use App\Models\ClarkImage;
use App\Models\ClarkEfrag;
use App\Models\ClarkDetail;
use App\Models\BrandType;
use App\Models\Brand;
use App\Models\Model;
use App\Models\BuyTransaction;
use App\Models\OrderSupplier;
use App\Models\Replyorder;
use App\Models\AllClark;
use App\Models\StoresLog;
use App\Models\Store;
use App\Models\EfragImages;
use App\Models\InvoiceImage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use File;
use DataTables;
use Carbon\Carbon;


class ClarksController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function indexWithRequest(Request $request)
    {
        if ($request->ajax()) {
            $data = Clark::all();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('name',function($row){
                    return $row->name ;
                })
                ->addColumn('clarkNumbers',function($row){
                    return isset($row->clark_number) ? $row->clark_number : '--';


                })
                ->addColumn('clarkSeries',function($row){
                    $clarkSeries= Series::where('id',$row->model_id)->get();
                    foreach ($clarkSeries as $key => $value) {
                        return isset($value->name) ? $value->name : '--';
                    }
                })
                ->addColumn('clarkBrand',function($row){
                    $clarkModel= Model::where('id',$row->model_id)->get();
                    foreach ($clarkModel as $key => $value) {
                        return isset($value->brand->name) ? $value->brand->name : '--';
                    }
                })

                ->addColumn('Image',function($row){
                    $clarkImage = ClarkImage::where('clark_id',$row->id)->get();
                    $html="";
                    foreach ($clarkImage as $key => $value) {
                        $html = $html . '<img class="rounded-circle header-profile-user" src="assets/clark_images/'. $value->image_name.'" alt="Emara">';
                    }
                    return $html;
                })
                ->addColumn('efragImage',function($row){
                    $efragImage = ClarkEfrag::where('clark_id',$row->id)->get();
                    $html="";
                    foreach ($efragImage as $key => $value) {
                        $html = $html . '<img class="rounded-circle header-profile-user" src="assets/efrag_images/'. $value->image_name.'" alt="Emara">';
                    }
                    return $html;
                })

                ->addColumn('action', function($row){

                    $btn = '<a  data-bs-toggle="modal"  clark_id_value="'.$row->id.'"  data-bs-target="#editClark"
                    data-toggle="tooltip" data-original-title="Edit" class="btn btn-primary btn-sm editClarkB"><i class="ri-edit-line editClarkButton"></i></a>';
                    $btn = $btn.' <form action="'.route("clark.destroy",$row->id).'" method="POST">'
                            . csrf_field()
                            . method_field('DELETE')
                            .'<input type="submit" value="Delete" class= "btn btn-danger">'.
                            '</form>';
                    $btn = $btn.'<a href="'.route("clark.print",$row->id ).'"
                    class="btn btn-success btn-sm printClark">Print<i class="ri-print-line"></i></a>';
                    return $btn;
                })
                ->rawColumns(['name','clarkNumbers','clarkSeries', 'clarkBrand','Image','efragImage','action'])
                ->make(true);
        }
    }

    public function indexWithID(Clark $clarkId)
    {

        $all_clark = AllClark::where('part_id' , $clarkId->id)->get();
        // return $all_clark;
        $clark=Clark::where('id' , $clarkId->id)
        ->with(['all_clarks'=>function($query){
                return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['replyorders'=>function($query2){
                        return $query2->get();
                }])->get();
                }]);
            }])

        ->with(['clark_details'=>function($query3){
            return $query3->with(['clark_spec'=>function($query4){
                return $query4->get();
            }])->get();
        }])
        ->with(['series'=> function($query8){
            return $query8->with(['model'=>function($query9){
                return $query9->with('brand')->with('brand_type')->get();
            }])->get();
        }])
        ->with('clark_images')
        ->with('clark_efrags')
        ->with(['invoice_images'=>function($query5){
            return $query5->where('part_type_id' , '4')->get();
        }])
        ->with(['related_clarks'=>function($query6){
            return $query6->with(['parts'=>function($query7){
                return $query7->get();
            }])->get();
        }])
        ->get();
        $store_log = StoresLog::where('All_part_id' , $all_clark[0]->id )->where( 'type_id' , '4')->get();
        return([$clark,$store_log]);

    }

    public function index()
    {

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
   public function store(Request $request)
    {
        Clark::create($request->all());
        $clark_id=Clark::max('id');

        if(isset($request->specs)){
            for ($i=0; $i < count($request->specs) ; $i++) {
                if($request->specs[$i] != null){
                    $specs = new ClarkSpec();
                    $specs->name = $request->specs[$i];
                    $specs->general_flag = $clark_id;
                    $specs->save();
                    $specDetail = new ClarkDetail();
                    $specDetail->partspecs_id = $specs->id;
                    $specDetail->clark_id = $clark_id;
                    if(isset($request->specsval)){
                        $specDetail->value = $request->specsval[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecs)){
            for ($j=0; $j < count($request->oldspecsval) ; $j++) {
                if($request->oldspecsval[$j] != null){
                    ClarkDetail::create(['partspecs_id'=> $request->oldSpecs[$j] ,'clark_id'=> $clark_id ,'value' => $request->oldspecsval[$j]]);
                }else{
                    continue;
                }

            }
        }

        if(isset($request->relatedPart)){
            for ($i=0; $i < count($request->relatedPart) ; $i++) {
                RelatedClark::create(['clark_id' => $clark_id , 'sug_part_id' => $request->relatedPart[$i]]);
            }
        }
        if(isset($request->clarkImg)){
            for ($i=0; $i < count($request->clarkImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->clarkImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->clarkImg[$i]->extension() ;
                $request->clarkImg[$i]->move(public_path('assets/clark_images'), $imageName);
                clarkImage::create(['clark_id' => $clark_id ,'name' => $namewithoutchar,  'image_name' => $imageName]);

            }
        }

        if(isset($request->releaseImg)){
            for ($i=0; $i < count($request->releaseImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->releaseImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->releaseImg[$i]->extension() ;
                $request->releaseImg[$i]->move(public_path('assets/efrag_images'), $imageName);
                ClarkEfrag::create(['clark_id' => $clark_id ,'name' => $namewithoutchar,  'image_name' => $imageName ,'company_id'=> $request->company_id]);

            }
        }


        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id ,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg)){
            for ($i=0; $i < count($request->invoiceImg) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg[$i]->extension() ;
                $request->invoiceImg[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $clark_id ,'name' => $namewithoutchar,  'image_name' => $imageName , 'part_type_id' =>'4' ]);
            }
        }

        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplayer_id,'status' =>'0' , 'container_size'=> $request->container_size , 'total_price' => $request->buy_price ,'deliver_date'=> $request->deliverydate , 'bank_account' => $request->bank_account , 'currency_id' => $request->currency_id ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $clark_id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'4' , 'price' => $request->buy_price, 'source_id' => $request->source_id ,'quality_id' => $request->quality_id, 'status_id' => $request->status ]);
        AllClark::create(['part_id' => $clark_id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id , 'status_id' => $request->status , 'buy_price' => $request->buy_price , 'insertion_date' => Carbon::now() , 'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id , 'lastupdate' => Carbon::now()]);
        $all_clark_id = AllClark::max('id');
        StoresLog::create(['All_part_id' => $all_clark_id , 'store_action_id' => '3' , 'store_id' => $request->store_id  , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '4']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);

                    // return $storeClsName;
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $clark_id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='4'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }
        return back()->with('success','You Have Successfully save Clark.');

    }


    /**
     * Display the specified resource.
     */
    public function show(Clark $clark)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Clark $clark)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Clark $clark)
    {
        // return $request->serivcedate_edit;
        $imgURLsInp = explode(',', $request->imgURLsInp[0]) ;
        $imgURLsInpInvoice = explode(',', $request->imgURLsInpInvoice[0]) ;
        $imgURLsInpEfrag = explode(',', $request->imgURLsInpEfrag[0]) ;

        for($i = 0 ; $i< count($imgURLsInpInvoice) ; $i++){
            if($imgURLsInpInvoice[$i] != null){
                $clark->invoice_images()->where('image_name', $imgURLsInpInvoice[$i])->delete();
            }
        }

        for($i = 0 ; $i< count($imgURLsInpEfrag) ; $i++){
            if($imgURLsInpEfrag[$i] != null){
                $clark->clark_efrags()->where('image_name', $imgURLsInpEfrag[$i])->delete();
            }
        }
        for($i = 0 ; $i< count($imgURLsInp) ; $i++){
            if($imgURLsInp[$i] != null){
                $clark->clark_images()->where('image_name', $imgURLsInp[$i])->delete();
            }
        }

        $relatedClark= RelatedClark::where('clark_id' ,$clark->id)->get();
        if(isset($relatedClark)){
            $relatedClark->each->delete();
        }

        $clark->clark_details()->delete();
        $clark_specs= ClarkSpec::where('general_flag' , $clark->id)->get();
        if(count($clark_specs)>0){
            $clark_specs->each->delete();
        }

        $all_clark = $clark->all_clarks()->first();
        if(isset($all_clark)){
            $order_supplier_id = $all_clark->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_clark->id)->where('type_id' , '4')->first();
        }

        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();
            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $clark->id)->where('type_id' , '4')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_clark)){
            AllClark::find($all_clark->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $clark->id)->where('part_type_id' , '4')->first();

        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        $clark->update(['name' => $request->name_edit , 'eng_name' => $request->name_en_edit , 'desc' => $request->desc_edit , 'serivcedate' => $request->serivcedate_edit , 'motor_number' => $request->motor_number_edit , 'clark_number' => $request->clark_number_edit , 'hours' => $request->hours_edit , 'color' => $request->color_edit , 'year' => $request->year_edit ,'front_tire' => $request->front_tire_edit ,'front_tire_status' => $request->front_tire_status_edit , 'rear_tire' => $request->rear_tire_edit , 'rear_tire_status'=> $request->rear_tire_status_edit , 'company_id' => $request->company_id ,'tank' => $request->tank_edit , 'power' => $request->power_edit , 'discs' => $request->discs_edit , 'status' => $request->status_edit , 'limit' => $request->limit_edit , 'active_limit' => $request->active_limit_edit , 'supplayer_id' => $request->supplayer_id_edit , 'gear_box' => $request->gear_box_edit, 'currency_id' => $request->currency_id_edit , 'source_id' => $request->source_id_edit , 'quality_id' => $request->quality_id_edit  , 'buy_price' => $request->buy_price_edit, 'model_id' => $request->model_id_edit]);

        if(isset($request->specsEdit)){
            for ($i=0; $i < count($request->specsEdit) ; $i++) {
                if($request->specsEdit[$i] != null){
                    $specs = new ClarkSpec();
                    $specs->name = $request->specsEdit[$i];
                    $specs->general_flag = $clark->id;
                    $specs->save();
                    $specDetail = new ClarkDetail();
                    $specDetail->partspecs_id = $specs->id;
                    $specDetail->clark_id = $clark->id;
                    if(isset($request->specsvalEdit)){
                        $specDetail->value = $request->specsvalEdit[$i];
                        $specDetail->save();
                    }
                    $specDetail->save();
                }
            }
        }
        if(isset($request->oldSpecsEdit)){
            for ($j=0; $j < count($request->oldSpecsEdit) ; $j++) {
                if($request->oldSpecsEdit[$j] != null){
                    ClarkDetail::create(['partspecs_id'=> $request->oldSpecsEdit[$j] ,'clark_id'=> $clark->id ,'value' => $request->oldspecsvalEdit[$j]]);
                }else{
                    continue;
                }
            }
        }

        if(isset($request->relatedPart_edit)){
            for ($i=0; $i < count($request->relatedPart_edit) ; $i++) {
                RelatedClark::create(['clark_id' => $clark->id , 'sug_part_id' => $request->relatedPart_edit[$i]]);
            }
        }

        if(isset($request->clarkImg_edit)){
            for ($i=0; $i < count($request->clarkImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->clarkImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->clarkImg_edit[$i]->extension() ;
                $request->clarkImg_edit[$i]->move(public_path('assets/clark_images'), $imageName);
                ClarkImage::create(['clark_id' => $clark->id , 'name' => $namewithoutchar, 'image_name' => $imageName]);
            }
        }

        if(isset($request->releaseImg_edit)){
            for ($i=0; $i < count($request->releaseImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->releaseImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->releaseImg_edit[$i]->extension() ;
                $request->releaseImg_edit[$i]->move(public_path('assets/efrag_images'), $imageName);
                ClarkEfrag::create(['clark_id' => $clark->id ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }

        BuyTransaction::create(['date'=> Carbon::now() , 'company_id'=> $request->company_id,'name' => Carbon::now(),  'final'=> '0' ,'creation_date'=> Carbon::now()]);
        $transaction_id = BuyTransaction::max('id');
        if(isset($request->invoiceImg_edit)){
            for ($i=0; $i < count($request->invoiceImg_edit) ; $i++) {
                $namewithoutchar = preg_replace('/[^A-Za-z0-9]/', '', $request->invoiceImg_edit[$i]->getClientOriginalName());
                $imageName = time() . $namewithoutchar.'.'.$request->invoiceImg_edit[$i]->extension() ;
                $request->invoiceImg_edit[$i]->move(public_path('assets/invoice_images'), $imageName);
                InvoiceImage::create(['part_id' => $clark->id ,'part_type_id' => '4' ,'name' => $namewithoutchar,  'image_name' => $imageName ]);

            }
        }

        OrderSupplier::create(['transaction_id' => $transaction_id , 'supplier_id' => $request->supplayer_id_edit,'status' =>'0' , 'container_size'=> $request->container_size_edit , 'total_price' => $request->buy_price_edit ,'deliver_date'=> $request->deliverydate_edit , 'bank_account' => $request->bank_account_edit, 'currency_id' => $request->currency_id_edit ,'confirmation_date' => Carbon::now() ]);
        $order_supplier_id = OrderSupplier::max('id');
        Replyorder::create(['part_id' => $clark->id , 'amount' => '1' , 'order_supplier_id' => $order_supplier_id , 'creation_date' => Carbon::now(), 'part_type_id' =>'4' , 'price' => $request->buy_price_edit, 'source_id' => $request->source_id_edit ,'quality_id' => $request->quality_id_edit, 'status_id' => $request->status_edit ]);
        AllClark::create(['part_id' => $clark->id , 'order_supplier_id' => $order_supplier_id , 'amount' => '1' , 'source_id' => $request->source_id_edit , 'status_id' => $request->status_id_edit , 'buy_price' => $request->buy_price_edit , 'remain_amount' => '1' , 'flag' => '3' , 'quality_id' => $request->quality_id_edit , 'lastupdate' => Carbon::now()]);
        $all_clark_id = AllClark::max('id');
        StoresLog::create(['All_part_id' => $all_clark_id , 'store_action_id' => '3' , 'store_id' => $request->store_id_edit , 'amount' => '1' , 'date' => Carbon::now() , 'status' => '3' , 'type_id' => '4']);
        $store_log_id = StoresLog::max('id');
        $store = Store::where('id' , $request->store_id_edit)->get();
        $storeClsName=ucfirst($store[0]->table_name );
                    $storeClsName ='App\Models\\'.$storeClsName;
                    $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
                    if($store[0]->table_name == "damaged_parts"){
                        $storeClsName = "App\Models\\DamagedPart";
                    }
                    try {
                        //code...
                        $storeCls = new $storeClsName();

                        $storeCls->part_id = $clark->id ;
                        $storeCls->amount = '1';
                        $storeCls->supplier_order_id = $order_supplier_id;
                        $storeCls->type_id ='4'; ;
                        $storeCls->store_log_id =$store_log_id ;
                        $storeCls->date = Carbon::now();
                        $storeCls->save();

                    } catch (\Throwable $th) {
                        //throw $th;
                    }
        return back()->with('success','You Have Successfully Updated Clark.');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Clark $clark)
    {
        $image_name= InvoiceImage::where('part_id' , $clark->id)->where('part_type_id' , '4')->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/invoice_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $invoice_image= InvoiceImage::where('part_id' , $clark->id)->where('part_type_id' , '4')->get();
        if(isset($invoice_image)){
            $invoice_image->each->delete();
        }

        $image_name = $clark->clark_efrags()->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/efrag_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $efrag_image= ClarkEfrag::where('clark_id' , $clark->id)->get();
        if(isset($efrag_image)){
            $efrag_image->each->delete();
        }

        $image_name = $clark->clark_images()->get('image_name');
        for($i=0 ; $i < count($image_name) ; $i++){
            $image_path = public_path('assets/clark_images/'.$image_name);
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
        }
        $clark_image= ClarkImage::where('clark_id' , $clark->id)->get();
        if(isset($clark_image)){
            $clark_image->each->delete();
        }
        $relatedClark= RelatedClark::where('clark_id' ,$clark->id)->get();
        if(isset($relatedClark)){
            $relatedClark->each->delete();
        }

        $clark->clark_details()->delete();
        $clark_specs= Clarkspec::where('general_flag' , $clark->id)->get();
        if(count($clark_specs)>0){
        $clark_specs->each->delete();
            }
        $all_clark = $clark->all_clarks()->first();
        if(isset($all_clark)){
            $order_supplier_id = $all_clark->order_supplier_id;
            $order_supplier = OrderSupplier::where('id' , $order_supplier_id)->first();
            $buy_transaction_id = $order_supplier->transaction_id;
            $buy_trnsaction = BuyTransaction::where('id' , $buy_transaction_id)->first();
            $store_log=StoresLog::where('All_part_id' , $all_clark->id)->where('type_id' , '4')->first();
        }
        if(isset($store_log)){
            $store = Store::where('id' , $store_log->store_id)->first();
            $storeClsName=ucfirst($store->table_name );
            $storeClsName ='App\Models\\'.$storeClsName;
            $storeClsName = str_replace([' ','_','-'],"",$storeClsName);
            if($store->table_name == "damaged_parts"){
                $storeClsName = "App\Models\\DamagedPart";
            }
            $storeCls = new $storeClsName();
            $toBeDeleted = $storeCls->where('part_id' , $clark->id)->where('type_id' , '4')->first();
        }
        if(isset($toBeDeleted)){
            DB::table($store->table_name)->where('part_id' , $toBeDeleted->part_id)->delete();
        }
        if(isset($store_log)){
            StoresLog::find($store_log->id)->delete();
        }
        if(isset($all_clark)){
            AllClark::find($all_clark->id)->delete();
        }
        $replyorder = Replyorder::where('part_id' , $clark->id)->where('part_type_id' , '4')->first();

        if(isset($replyorder)){
            Replyorder::where('id', $replyorder->id)->delete();

        }
        if(isset($order_supplier)){
            OrderSupplier::where('id', $order_supplier_id)->delete();
        }
        if(isset($buy_trnsaction)){
            BuyTransaction::where('id', $buy_transaction_id)->delete();
        }
        Clark::where('id' , $clark->id)->delete();
        return back()->with('success','You Have Successfully Deleted Clark.');
    }

    public function clarkspecs(){

        return ClarkSpec::where('general_flag','0')->get();
    }

    public function clarkBrand(){
        $brandType = BrandType::all();
        $brand = Brand::all();
        return[$brandType , $brand];
    }

    public function clarkmodel($brandId,$ttypeid){
        return Model::where('brand_id',$brandId)->where('type_id',$ttypeid)->get();
    }

    public function clarkseries($modelId){
        $series =  Series::where('model_id',$modelId)->with('model')->get();
        return $series;
    }

    public function printclark($clark_id){
        $clark =  Clark::where('id' , $clark_id)

        ->with(['all_clarks'=>function($query){
            return $query->with(['order_supplier'=>function($query1){
                    return $query1->with(['buy_transaction'=>function($query2){
                        return $query2->get();
                }])->with('currency_type')
                    ->with('supplier')
                    ->get();
            }])
            ->with('source')
            ->with('status')
            ->with('part_quality')
            ->get();
        }])
        ->with(['clark_details'=>function($query){
            return $query->with(['clark_spec'=>function($query1){
                return $query1->get();
            }])->get();
        }])
        ->with(['series'=>function($query){
            return $query->with(['model'=>function($query1){
                    return $query1->with(['brand'=>function($query2){
                        return $query2->get();
                }])->get();
            }]);
        }])
        ->with('rearTires')
        ->with('frontTires')
        ->with('clark_images')->first();
        // return $clark;
        return view("printClark",compact("clark"));
    }
}