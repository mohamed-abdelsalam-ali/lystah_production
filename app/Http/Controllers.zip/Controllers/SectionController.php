<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StoreStructure;
use App\Models\Store;



class SectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $all_store_structures=StoreStructure::with('store')->get();
        $stores=Store::all();
        // return $all_store_structures;
        return view('sections.index',compact('all_store_structures','stores'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // return $request;
        StoreStructure::create([
            'name'=>$request->name,
            'store_id'=>$request->store_id,
            'notes'=>$request->notes,
        ]);
        session()->flash("success", "تم الاضافة بنجاح");
        return redirect()->route('section.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }
    
    public function GetSections(Store $store)
    {
        return StoreStructure::where('store_id',$store->id)->with('store')->get();
        
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {
        // return $request;
        $section=StoreStructure::where('id',$request->section_id)->first();
        $section->update([
            'name'=>$request->name,
            'store_id'=>$request->store_id,
            'notes'=>$request->notes,
        ]);
        session()->flash("success", "تم التعديل بنجاح");
        return redirect()->route('section.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        // return $request;
        $section=StoreStructure::where('id',$request->section_id)->first();
        $section->delete();
        session()->flash("success", "تم حذف بنجاح");
        return redirect()->route('section.index');


    }
}
