<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Client;
use App\Models\Invoice;
use App\Models\InvoiceClientMadyonea;
use App\Models\OrderSupplier;
use App\Models\RefundInvoice;

class ClientHesapController extends Controller
{
    //
    public function index()
    {
        //
        $clients = Client::all();
        // $user = User::all();
        // $PaymentMethod = PaymentMethod::all();
        // $login_user = auth()->user();
        // return $login_user;
        return view('client_statment.client_hesap', compact('clients'));

    }


    public function show($id)
    {
        //where('remian_price','>',0)->where('invoice_type_id','<>',2)->
        // $all_invoices = ClientInvoice::where('client_id', '=', $id)
        //     ->with('client')
        //     ->with('payment_method')
        //     ->with('invoice_type')
        //     ->with('client_invoice_rents')
        //     ->with('client_refund')
        //     ->with([
        //         'client_items' => function ($query) {
        //             $query->where('flag_amount_updated', '=', 0);
        //         },
        //     ])
        //     ->with('client_payments')
        //     ->with('user')
        //     ->with('counter')
        //     ->with('items_invoices_name')
        //     ->get();
        // $all_invoices_total_rent = ClientInvoice::where('client_id', '=', $id)
        //     ->where('invoice_type_id', '<>', 2)
        //     ->with('client')
        //     ->with('payment_method')
        //     ->with('invoice_type')
        //     ->with('client_invoice_rents')
        //     ->with([
        //         'client_items' => function ($query) {
        //             $query->where('flag_amount_updated', '=', 0);
        //         },
        //     ])
        //     ->with('client_payments')
        //     ->with('client_refund')
        //     ->with('user')
        //     ->with('counter')
        //     ->sum('total');
        // $all_invoices_total_sell = ClientInvoice::where('client_id', '=', $id)
        //     ->where('invoice_type_id', '=', 2)
        //     ->with('client')
        //     ->with('payment_method')
        //     ->with('invoice_type')
        //     ->with('client_invoice_rents')
        //     ->with([
        //         'client_items' => function ($query) {
        //             $query->where('flag_amount_updated', '=', 0);
        //         },
        //     ])
        //     ->with('client_payments')
        //     ->with('client_refund')

        //     ->with('user')
        //     ->with('counter')
        //     ->sum('total');
        // $all_invoices_remain = ClientInvoice::where('client_id', '=', $id)
        //     ->with('client')
        //     ->with('payment_method')
        //     ->with('invoice_type')
        //     ->with('client_invoice_rents')
        //     ->with([
        //         'client_items' => function ($query) {
        //             $query->where('flag_amount_updated', '=', 0);
        //         },
        //     ])
        //     ->with('client_payments')
        //     ->with('client_refund')

        //     ->with('user')
        //     ->with('counter')
        //     ->sum('remian_price');

        // // return $all_invoices_total;
        // return [$all_invoices, $all_invoices_total_rent, $all_invoices_total_sell, $all_invoices_remain];
    }
    public function get_inv($id)
    {
        // $invoice = ClientInvoice::where('id', $id)
        //     ->with('client')
        //     ->with('payment_method')
        //     ->with('invoice_type')
        //     ->with('client_payments_recep')
        //     ->with('client_invoice_rents')
        //     ->with([
        //         'client_items' => function ($query) {
        //             $query->where('flag_amount_updated', '=', 0);
        //         },
        //     ])
        //     ->with('client_payments')
        //     ->with('user')
        //     ->with('counter')
        //     ->first();
        // return $invoice;
    }
    public function client_hesap()
    {
        $clients = Client::all();
        return view('items.client_hesap', compact('clients'));
    }
    public $start_date1;
    public $end_date1;

    public function hessap($id)
    {
        $client_data = Client::where('id', '=', $id)->get();


        // return $id;
        $this->start_date1 = $_GET['start_date'];
        $this->end_date1 = $_GET['end_date'];
        $start_date = $this->start_date1;
        $end_date = $this->end_date1;

        if ($start_date && $end_date) {
                // return 'start_date';
                $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')

                            ->whereDate('date','>=',$start_date)
                              ->whereDate('date','<=',$end_date)
                            ->get();  //invoice_data
                 $refund_data= [];
                foreach ($Client_invoince as $C_inv) {
                    # code...
                     $refund_invoince = RefundInvoice::whereBetween('date', [$start_date, $end_date])
                     ->whereDate('date','>=',$start_date)
                       ->whereDate('date','<=',$end_date)
                     ->where('invoice_id','=' ,$C_inv->id)->get();

                    if(count($refund_invoince)>0){
                        array_push($refund_data,$refund_invoince);
                    }

                }
                // return $refund_data;
                 $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)

                 ->whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','>=',$start_date)
                              ->whereDate('date','<=',$end_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }


        } elseif ($start_date && !$end_date) {
            // return 'start_date';

            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->whereDate('date', '>=', $start_date)
            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereBetween('date', [$start_date, $end_date])
                 ->whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
            }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->whereDate('date', '>=', $start_date)->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','>=',  $start_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }

        } elseif (!$start_date && $end_date) {
            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->whereDate('date', '<=', $end_date)

            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
            }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->whereDate('date', '<=', $end_date)
                ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','<=',  $end_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }


        } elseif (!$start_date && !$end_date) {
            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereBetween('date', [$start_date, $end_date])
                 ->whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
            }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with('buy_transaction')->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }



        }

         return ['client_data' => $client_data, 'Client_invoince' => $Client_invoince, 'client_mad' => $client_mad,'Buy_invoince'=>$Buy_invoince ,'refund_data'=>$refund_data];
    }

    public function hesssap_print($id, $start_date, $end_date)
    {
        $client_data = Client::where('id', '=', $id)->get();


        // return $id;
        // $this->start_date1 = $_GET['start_date'];
        // $this->end_date1 = $_GET['end_date'];
        // $start_date = $this->start_date1;
        // $end_date = $this->end_date1;
        if ($start_date && $end_date && $start_date != 'null' && $end_date != 'null') {

                $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
                            ->whereDate('date','>=',$start_date)
                              ->whereDate('date','<=',$end_date)
                            ->get();  //invoice_data
                 $refund_data= [];
                foreach ($Client_invoince as $C_inv) {
                    # code...
                     $refund_invoince = RefundInvoice::whereDate('date','>=',$start_date)
                       ->whereDate('date','<=',$end_date)
                     ->where('invoice_id','=' ,$C_inv->id)->get();

                    if(count($refund_invoince)>0){
                        array_push($refund_data,$refund_invoince);
                    }

                }
                // return $refund_data;
                 $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                 ->whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','>=',$start_date)
                              ->whereDate('date','<=',$end_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }


        }elseif (($start_date && !$end_date) || ($start_date != 'null' && $end_date == 'null')) {

            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->whereDate('date', '>=', $start_date)
            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
                }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->whereDate('date', '>=', $start_date)->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','>=',  $start_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }

        } elseif ((!$start_date && $end_date) || ($start_date == 'null' && $end_date != 'null')) {


            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->whereDate('date', '<=', $end_date)
            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
            }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->whereDate('date', '<=', $end_date)
                ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with([
                        "buy_transaction"=>function ($query) use ($start_date,$end_date){
                            $query->whereDate('date','<=',  $end_date);
                        }])->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }


        } elseif ((!$start_date && !$end_date) || ($start_date == 'null' && $end_date == 'null')) {
            $Client_invoince = Invoice::where('client_id', '=', $id)->with('store')
            ->get();  //invoice_data
            $refund_data= [];
            foreach ($Client_invoince as $C_inv) {
                # code...
                 $refund_invoince = RefundInvoice::whereDate('date','>=',$start_date)
                   ->whereDate('date','<=',$end_date)
                 ->where('invoice_id','=' ,$C_inv->id)->get();


                 if(count($refund_invoince)>0){
                    array_push($refund_data,$refund_invoince);
                }
            }
                $client_mad = InvoiceClientMadyonea::where('client_id', '=', $id)
                ->get();  // = Client_pament سندات القيض
                $Buy_invoince = [];
                if ($client_data[0]->sup_id != null) {
                    $Buy_invoince = OrderSupplier::where('supplier_id', '=', $client_data[0]->sup_id)
                    ->with('buy_transaction')->with(['currency_type'=>function($q){
                            $q->with(['currencies'=>function($m){
                                $m->where('to',null)->first();
                            }]);
                        }])->get();  //buy_invoice

                }



        }
        // return $Buy_invoince;
        //  return ['client_data' => $client_data, 'Client_invoince' => $Client_invoince, 'client_mad' => $client_mad,'Buy_invoince'=>$Buy_invoince ,'refund_data'=>$refund_data ];


        return view('client_statment.hessap_print', compact('client_data', 'Client_invoince', 'client_mad','Buy_invoince','refund_data', 'start_date', 'end_date'));
    }


}
