<?php

namespace App\Http\Controllers;

use App\Models\AllPart;
use App\Models\AllKit;
use App\Models\AllWheel;
use App\Models\Currency;
use App\Models\CurrencyType;
use App\Models\PricingType;
use App\Models\SalePricing;
use App\Models\SaleType;
use App\Models\Store;
use Carbon\Carbon;
use App\Models\AllTractor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Collection;

class PricingController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $allparts1 = AllPart::where('remain_amount' ,'>',0)->groupBy(['part_id','source_id','status_id','quality_id'])->select('part_id','source_id','status_id','quality_id')->with('part')->with('source')->with('status')->with('part_quality')->get();
        foreach ($allparts1 as $key => $part1) {
            $part1['pricing'] = SalePricing::where('to',null)->where('part_id',$part1->part_id)->where('status_id',$part1->status_id)->where('source_id',$part1->source_id)->where('quality_id',$part1->quality_id)->with('sale_type')->get();
            $part1['lastpricing'] = AllPart::where('part_id',$part1->part_id)->where('status_id',$part1->status_id)->where('source_id',$part1->source_id)->where('quality_id',$part1->quality_id)->orderBy('id','DESC')->with('order_supplier')->first();
            $part1['lastPricing0'] = SalePricing::where('part_id',$part1->part_id)->where('status_id',$part1->status_id)->where('source_id',$part1->source_id)->where('quality_id',$part1->quality_id)->with('sale_type')->orderBy('id','DESC')->get();

        }

        $allkits = AllKit::where('remain_amount' ,'>',0)->groupBy(['part_id','source_id','status_id','quality_id'])->select('part_id','source_id','status_id','quality_id')->with('kit')->with('source')->with('status')->with('part_quality')->get();
        foreach ($allkits as $key => $part) {
            $part['pricing'] = SalePricing::where('to',null)->where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->get();
            $part['lastpricing'] = AllKit::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->orderBy('id','DESC')->with('order_supplier')->first();
            $part['lastPricing0'] = SalePricing::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->orderBy('id','DESC')->get();

        }

        $allwheels = AllWheel::where('remain_amount' ,'>',0)->groupBy(['part_id','source_id','status_id','quality_id'])->select('part_id','source_id','status_id','quality_id')->with('wheel')->with('source')->with('status')->with('part_quality')->get();
        foreach ($allwheels as $key => $part) {
            $part['pricing'] = SalePricing::where('to',null)->where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->get();
            $part['lastpricing'] = AllWheel::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->orderBy('id','DESC')->with('order_supplier')->first();
            $part['lastPricing0'] = SalePricing::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->orderBy('id','DESC')->get();

        }
        
        $alltractors = AllTractor::where('remain_amount' ,'>',0)->groupBy(['part_id','source_id','status_id','quality_id'])->select('part_id','source_id','status_id','quality_id')->with('tractor')->with('source')->with('status')->with('part_quality')->get();
        foreach ($alltractors as $key => $part) {
            $part['pricing'] = SalePricing::where('to',null)->where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->get();
            $part['lastpricing'] = AllTractor::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->orderBy('id','DESC')->with('order_supplier')->first();
            $part['lastPricing0'] = SalePricing::where('part_id',$part->part_id)->where('status_id',$part->status_id)->where('source_id',$part->source_id)->where('quality_id',$part->quality_id)->with('sale_type')->orderBy('id','DESC')->get();

        }

        $allparts = new \Illuminate\Database\Eloquent\Collection; //Create empty collection which we know has the merge() method
        $allparts = $allparts->concat($allparts1);
        $allparts = $allparts->concat($allkits);
        $allparts = $allparts->concat($allwheels);
        $allparts = $allparts->concat($alltractors);

// return $alltractors;
        // $allparts = collect($allparts1,$allkits);

        // $allparts = $allparts1->merge($allkits)->merge($allwheels);
        // return  $allparts;

        $pricingTypes = PricingType::all();
        $currency = CurrencyType::with(['currencies'=>function($query){
            return $query->where('to',null);
        }])->get();
        $currencyHistory = Currency::where('to',null)->with('currency_type')->get();
        // return $allparts;
        return view('pricing',compact('allparts','pricingTypes','currency','currencyHistory'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
        // return $request;
        $xxx = [];
        $saleTypes = PricingType::all();
        // return $saleTypes;
        foreach ($request->partId as $key => $part) {
            $source = $request->source[$key];
            $status = $request->status[$key];
            $quality = $request->quality[$key];

            
                for ($i=0; $i < count($saleTypes) ; $i++) {
                    $saleTypeid = $saleTypes[$i]->id;
                    
                    $saleTypeName = 'price-'.$saleTypes[$i]->id;
                    
                    $price = $request->$saleTypeName[$key];
                    // echo $price . '-';
                    //  $x = SalePricing::where('part_id',$part)->where('source_id',$source)->where('sale_type',$saleTypeid)->where('status_id',$status)->where('quality_id',$quality)->orderBy('id','DESC')->first();
                    // if(isset($x->to)){
                    //     SalePricing::where('part_id',$part)->where('source_id',$source)->where('sale_type',$saleTypeid)->where('status_id',$status)->where('quality_id',$quality)->orderBy('id','DESC')->first()->update(['to'=>null]);
                    // }                           
                    ////////////////////////////////end salam
                    $cond = SalePricing::where('to',null)->where('part_id',$part)->where('sale_type',$saleTypeid)->where('source_id',$source)->where('status_id',$status)->where('quality_id',$quality)->update(['to'=>Carbon::now()]);
                    if( $price <> 0  ){
                        $pricing = new SalePricing();
                        $pricing->part_id = $part;
                        $pricing->source_id = $source;
                        $pricing->status_id = $status;
                        $pricing->quality_id = $quality;
                        $pricing->from = Carbon::now();
                        $pricing->to = null;
                        $pricing->type_id = $request->type[$key];
                        $pricing->currency_id = $request->currencySlct;
                        $pricing->sale_type = $saleTypeid;
                        $pricing->price = $price;
                        // end old pricing ////////////////////////
                        
                                    
                        // end old pricing ////////////////////////
                        $pricing->save();
                    }
               

            }
              

        } 
        



        return $this->index();
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
