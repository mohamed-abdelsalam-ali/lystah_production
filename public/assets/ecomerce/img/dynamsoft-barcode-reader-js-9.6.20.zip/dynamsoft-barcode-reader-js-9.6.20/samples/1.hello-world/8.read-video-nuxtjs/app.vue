<template>
  <div>
    <HelloWorld />
  </div>
</template>
