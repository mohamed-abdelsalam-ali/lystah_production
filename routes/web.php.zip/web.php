<?php

use App\Http\Controllers\ClientController;
use App\Http\Controllers\GroupsController;
use App\Http\Controllers\PartsController;
use App\Http\Controllers\KitsController;
use App\Http\Controllers\NumbersController;
use App\Http\Controllers\WheelsController;
use App\Http\Controllers\WheelDimensionController;
use App\Http\Controllers\WheelModelController;
use App\Http\Controllers\WheelMaterialController;
use App\Http\Controllers\WheelSpecController;
use App\Http\Controllers\RelatedWheelController;
use App\Http\Controllers\StoreManageController;
use App\Http\Controllers\SubGroupsController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\PartNumberController;
use App\Http\Controllers\POSController;
use App\Http\Controllers\GroupController;
use App\Http\Controllers\PricingController;
use App\Models\Supplier;
use App\Http\Controllers\Store\TransactionController;
use App\Http\Controllers\Store\StoreTransactionController;
use App\Http\Controllers\Store\StoreCoverController;
use App\Models\PartNumber;
use Illuminate\Http\Request;
use App\Http\Controllers\kitCollectionController;
use App\Http\Controllers\AllPartsController;
use App\Http\Controllers\BankSafeMoneyController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\UserRoleController;
use App\Http\Controllers\RolePermissionController;

use App\Http\Controllers\TractorsController;
use App\Http\Controllers\ClarksController;
use App\Http\Controllers\EquipsController;

use Illuminate\Support\Facades\Route;
use Symfony\Component\Console\Input\Input;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\BrandTypeController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\CurrencyTypeController;
use App\Http\Controllers\DriveController;
use App\Http\Controllers\GearboxController;
use App\Http\Controllers\ModelController;
use App\Http\Controllers\PartQualityController;
use App\Http\Controllers\PricingTypeController;
use App\Http\Controllers\SeriesController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\SourceController;
use App\Http\Controllers\StatusController;
use App\Http\Controllers\SupplierBankController;
use App\Http\Controllers\TaxesController;
use App\Http\Controllers\ClientHesapController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\CountryController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\EmployeeSalaryController;
use App\Http\Controllers\SafeMoneyController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\NoteSafeMoneyController;
use App\Http\Controllers\SolfaController;
use App\Http\Controllers\BankTypeController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\sellInvoiceController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\QaydController;
use App\Http\Controllers\QaydTypeController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');
Route::get('/', function () {

    return view('auth.login');
});

Route::middleware('auth')->group(function () {
    // Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    // Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    // Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');


    Route::get('/home', [HomeController::class,'index']);

    Route::get('parts', function () {
        return view('parts');
    });

    Route::Resource('part', PartsController::class);
    
     Route::GET('partIdData/{partId}', [PartsController::class, 'indexWithID'])->name('partIdData');
     Route::delete('part.destroy/{partId}', [PartsController::class, 'destroy'])->name('part.destroy');
    
     
     
     
    Route::POST('checkout', [PartsController::class, 'checkout'])->name('checkout');
    Route::GET('partsData', [PartsController::class, 'indexWithRequest'])->name('partsData');
    Route::GET('partsSearch', [PartsController::class, 'partsSearch'])->name('partsSearch');
    Route::GET('partsSearchNumber/{num}', [PartsController::class, 'partsSearchNumber'])->name('partsSearchNumber');
    Route::GET('partsSearchName/{name}', [PartsController::class, 'partsSearchName'])->name('partsSearchName');
    Route::GET('partSearchWithId/{id}', [PartsController::class, 'partSearchWithId'])->name('partSearchWithId');
    Route::GET('partUnderSubGroup/{subgroupid}', [PartsController::class, 'partUnderSubGroup'])->name('partUnderSubGroup');

    Route::GET('partspecs', [PartsController::class, 'partspecs'])->name('partspecs');
    Route::GET('partBrand', [PartsController::class, 'partBrand'])->name('partBrand');
    Route::GET('partsubgroup/{groupId}', [PartsController::class, 'partsubgroup'])->name('partsubgroup');

    Route::GET('kits', function () {
        return view('kitIndex');
    });
    Route::GET('kitIdData/{kitId}', [KitsController::class, 'indexWithID'])->name('kitIdData');
    Route::GET('kitsdata', [KitsController::class, 'indexWithRequest'])->name('kitsdata');
    Route::POST('kitStore', [KitsController::class, 'store'])->name('kitStore');
    Route::Resource('kit', KitsController::class);
    Route::GET('kitspecs', [KitsController::class, 'kitspecs'])->name('kitspecs');
    Route::GET('kitBrand', [KitsController::class, 'kitBrand'])->name('kitBrand');
    Route::GET('part', [PartsController::class, 'index'])->name('part');


    Route::GET('wheels', function () {
        return view('wheelIndex');
    });
    Route::GET('wheelIdData/{wheelId}', [WheelsController::class, 'indexWithID'])->name('wheelIdData');
    Route::GET('wheelsdata', [WheelsController::class, 'indexWithRequest'])->name('wheelsdata');
    Route::POST('wheelStore', [WheelsController::class, 'store'])->name('wheelStore');
    Route::Resource('wheel', WheelsController::class);
    Route::resource('wheeldimensions', WheelDimensionController::class);
    Route::resource('wheelmodel', WheelModelController::class);
    Route::resource('wheelmaterial', WheelMaterialController::class);
    Route::resource('wheelspecs', WheelSpecController::class);
    Route::resource('relatedwheel', RelatedWheelController::class);

    Route::GET('tractors', function () {
        return view('tractorIndex');
    });
    Route::GET('tractorsdata', [KitsController::class, 'indexWithRequest'])->name('kitsdata');




    Route::GET('brandUnderSupplier/{supplierId}/{type_id}', [PartsController::class, 'brandUnderSupplier'])->name('brandUnderSupplier');
    Route::GET('brandTypeUnderSupplier/{supplierId}', [PartsController::class, 'brandTypeUnderSupplier'])->name('brandTypeUnderSupplier');
    Route::GET('ModelUnderSupplier/{supplierId}/{modelId}', [PartsController::class, 'ModelUnderSupplier'])->name('ModelUnderSupplier');
    Route::GET('SeriesUnderSupplier/{supplierId}/{seriesId}', [PartsController::class, 'SeriesUnderSupplier'])->name('SeriesUnderSupplier');
    Route::GET('PartUnderSupplier/{supplierId}', [PartsController::class, 'PartUnderSupplier'])->name('PartUnderSupplier');


    Route::GET('source', [StoreManageController::class, 'source'])->name('source');
    Route::GET('status', [StoreManageController::class, 'status'])->name('status');
    Route::GET('quality', [StoreManageController::class, 'quality'])->name('quality');


    Route::GET('partmodel/{Bid}/{ptypeid}', [PartsController::class, 'partmodel'])->name('partmodel');
    Route::GET('partseries/{Mid}', [PartsController::class, 'partseries'])->name('partseries');
    Route::GET('partSearchSeries/{sid}', [PartsController::class, 'partSearchSeries'])->name('partSearchSeries');
    Route::post('store-part', [PartsController::class, 'store']);


    Route::resource('groups', GroupController::class);
    Route::resource('subgroups', SubGroupsController::class);
    Route::resource('supplierindex', SupplierController::class);
    Route::GET('supplier', [SupplierController::class, 'get_all_sup'])->name('get_all_sup');

    Route::GET('supplier', [SupplierController::class, 'get_all_sup'])->name('supplier');


    Route::GET('Selectindex', [SupplierController::class, 'Selectindex'])->name('Selectindex');

    Route::resource('client', ClientController::class);

    Route::resource('pos', POSController::class);
    Route::GET('shop', [POSController::class, 'shop'])->name('shop');
    Route::GET('CardInfo', [POSController::class, 'CardInfo'])->name('CardInfo');
    Route::POST('printpos', [POSController::class, 'printpos'])->name('printpos');
    Route::POST('saveMadyonea', [POSController::class, 'saveMadyonea'])->name('saveMadyonea');
    Route::GET('printBarcode/{barcodeTxt}/{name}', [POSController::class, 'printBarcode'])->name('printBarcode');
    Route::POST('saveClientPrice', [POSController::class, 'saveClientPrice'])->name('saveClientPrice');




    Route::GET('newClientInline/{telNumber}', [POSController::class, 'newClientInline'])->name('newClientInline');
    Route::GET('storeSections/{storeId}', [POSController::class, 'storeSections'])->name('storeSections');
    Route::GET('getAllDataInSection/{sectionId}/{storeId}', [POSController::class, 'getAllDataInSection'])->name('getAllDataInSection');
    Route::POST('saveNewSection', [POSController::class, 'saveNewSection'])->name('saveNewSection');
    Route::GET('Clientinvoice/{clientId}/{storeId}', [POSController::class, 'Clientinvoice'])->name('Clientinvoice');
    Route::GET('Clientinvoiceprice/{clientId}/{storeId}', [POSController::class, 'Clientinvoiceprice'])->name('Clientinvoiceprice');
    Route::POST('saveclientinvoiceprice', [POSController::class, 'saveclientinvoiceprice'])->name('saveclientinvoiceprice');
    Route::GET('getquoteData/{id}/{storeId}', [POSController::class, 'getquoteData'])->name('getquoteData');

    Route::GET('GetSections/{store}', [SectionController::class, 'GetSections'])->name('GetSections');

    Route::GET('shoptest', [POSController::class, 'shoptest'])->name('shoptest');

    // Route::get('shop', function () {


    //     return view('ecommerce.shop-grid');
    // });


    Route::GET('stores', [StoreManageController::class, 'stores'])->name('stores');

    Route::GET('GetAllstores', [StoreManageController::class, 'GetAllstores'])->name('GetAllstores');
    Route::GET('gard/{storeid}', [StoreManageController::class, 'gard']);

    Route::POST('storeSend1', [StoreManageController::class, 'storeSend1'])->name('storeSend1');

    Route::resource('pricing', PricingController::class); // التسعيرة

    Route::resource('storeManage', StoreManageController::class); // فاتورة الشراء
    Route::POST('storeManage1', [StoreManageController::class, 'storeManage']); // فاتورة الشراء + ا
    Route::POST('storeManage2', [StoreManageController::class, 'storeManage2']); // فاتورة الشراء + التوزيع
    Route::GET('buyInvData', [StoreManageController::class, 'indexWithRequest'])->name('buyInvData');
    Route::GET('sellInvoices', [sellInvoiceController::class,'index'])->name('sellInvoices'); //  فاتورة البيع

    Route::GET('sellInvData', [sellInvoiceController::class, 'indexWithRequest'])->name('sellInvData');
    Route::GET('lastInvId', [StoreManageController::class, 'lastInvId'])->name('lastInvId');
    Route::GET('customSearch', [PartsController::class, 'customSearch'])->name('customSearch');
    Route::POST('customSearchResult', [PartsController::class, 'customSearchResult'])->name('customSearchResult');
    Route::POST('saveInv', [PartsController::class, 'saveInv'])->name('saveInv');

    Route::GET('printInvoice/{id}', [PartsController::class, 'printInvoice']);
    Route::GET('printBuyInvoice/{id}', [StoreManageController::class, 'printBuyInvoice']);
    Route::GET('storeManageItems/{id}', [StoreManageController::class, 'storeManageItems']);
    Route::POST('editBuyInv', [StoreManageController::class, 'editBuyInv'])->name('editBuyInv');
    Route::GET('buyInv/{id}', [StoreManageController::class, 'buyInv']);
    Route::GET('buyinv2', [StoreManageController::class, 'buyinvnewPage']);
    Route::GET('deleteInv/{id}', [StoreManageController::class, 'deleteInv'])->name('deleteInv');


    // Route::get('/file-import',[StoreManageController::class,'importView'])->name('import-view');
    // Route::post('importExcel',[StoreManageController::class,'import'])->name('importExcel');


    ////////////////////////////////////client_statment/////////////////////////////////////////////

    Route::GET('clientStatment', [ClientHesapController::class, 'index'])->name('clientStatment');
    Route::get('/hesssap_print/{id}/{sdate}/{edate}', [ClientHesapController::class, 'hesssap_print'])->name('hesssap_print');
    Route::get('/hessap/{id}', [ClientHesapController::class, 'hessap'])->name('hessap');

    ///////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////// SALAM //////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////

    Route::get('/event', function () {

        event(new \App\Events\NewTrade('new message for new event'));
    });
    // move new parts and confirm transactions ------------------------------
    Route::get('/all_buy_invs', [TransactionController::class, 'index']);
    Route::get('/items_inv/{id}', [TransactionController::class, 'show'])->name('items_inv');
    Route::POST('/saveTransaction', [TransactionController::class, 'send_new_parts'])->name('saveTransaction');
    Route::POST('/confirmStoreTrans', [TransactionController::class, 'confirm_store_trans'])->name('confirmStoreTrans');
    Route::POST('/confirmStore', [POSController::class, 'confirm_store'])->name('confirmStore');
    Route::POST('/refuseStoreTrans', [TransactionController::class, 'refuse_store_trans'])->name('refuseStoreTrans');
    Route::POST('/hideStoreTrans', [TransactionController::class, 'hide_store_trans'])->name('hideStoreTrans');
    Route::get('/inboxAdmin', [TransactionController::class, 'inbox_admin_history'])->name('inboxAdmin');
    Route::get('/inboxAdmin/list', [TransactionController::class, 'inbox_admin_history1'])->name('inboxAdmin.list');
    Route::get('/inboxStore', [POSController::class, 'store_inbox_history'])->name('inboxStore');
    Route::get('/inboxStore/list/{storeId}', [POSController::class, 'store_inbox_history1'])->name('inboxStore.list');

    Route::get('/itemsStore', [POSController::class, 'store_items_history'])->name('itemsStore');
    Route::get('/itemsStore/list/{storeId}', [POSController::class, 'store_items_history1'])->name('itemsStore.list');
    Route::get('/sendToOtherStore', [POSController::class, 'send_to_other_store'])->name('sendToOtherStore');

    // End move new parts and confirm transactions ------------------------------
    Route::get('/store/{id}', [StoreTransactionController::class, 'show'])->name('store');
    Route::get('/store_cover', [StoreCoverController::class, 'index']);
    Route::Resource('numbers', NumbersController::class);
    Route::GET('dtNumbers', [NumbersController::class, 'indexWithRequest'])->name('dtNumbers');





    Route::get('/items_inv', function () {

        event(new \App\Events\SaveTransaction('inbox'));
    });
    Route::get('/confirmStore', function () {

        event(new \App\Events\StoreTranaction('inbox'));
    });
    // Route::get('/inboxAdmin', function () {

    //     event(new \App\Events\SaveTransaction('inbox'));

    // });
    Route::get('/listen', function () {
        return view('test_event');
    });

    //////////////////////////////////Adel////////////////////////////////////////////////////////
    
    Route::POST('/useSupAsClient', [SupplierController::class, 'use_Sup_As_Client'])->name('useSupAsClient');
    Route::POST('/useSupAsSupplier', [SupplierController::class, 'use_client_as_suplier'])->name('useSupAsSupplier');
    Route::POST('/checkSupAsClient', [SupplierController::class, 'check_Sup_As_Client'])->name('checkSupAsClient');
    Route::resource('company', CompanyController::class);
    Route::resource('all_status', StatusController::class);
    Route::resource('supplier_bank', SupplierBankController::class);
    Route::GET('show_account_bank/{id}', [SupplierController::class, 'show_account_bank'])->name('show_account_bank');
    Route::resource('currency_type', CurrencyTypeController::class);
    Route::get('currencyType', [CurrencyTypeController::class, 'get_all_currency'])->name('currencyType');

    Route::GET('show_currency/{id}', [CurrencyTypeController::class, 'show_currency'])->name('show_currency');
    Route::GET('GetAllCurrency', [CurrencyTypeController::class, 'GetAllCurrency'])->name('GetAllCurrency');
    Route::resource('currency', CurrencyController::class);
    Route::resource('unit', UnitController::class);
    Route::resource('brand', BrandController::class);
    Route::resource('brand_type', BrandTypeController::class);
    Route::resource('model', ModelController::class);
    Route::resource('series', SeriesController::class);
    Route::resource('group', GroupsController::class);
    Route::resource('sub_group', SubGroupsController::class);
    /////////////////////////////////UserController///////////////////////////
    Route::resource('users', UserController::class);
    Route::get('/update_password', [UserController::class, 'update_password'])->name('update_password');
    /////////////////////////////////Adel_new///////////////////////////

    Route::resource('gearbox', GearboxController::class);
    Route::GET('show_catalog/{id}', [SubGroupsController::class, 'show_catalog'])->name('show_catalog');
    Route::resource('catalog', CatalogController::class);
    Route::resource('drive', DriveController::class);
    Route::resource('part_quality', PartQualityController::class);
    Route::get('partQuality', [PartQualityController::class, 'get_all_p_quality'])->name('partQuality');
    Route::resource('pricing_type', PricingTypeController::class);
    Route::resource('service', ServiceController::class);
    Route::resource('all_source', SourceController::class);
    Route::resource('taxes', TaxesController::class);
    Route::resource('client', ClientController::class);
    Route::resource('section', SectionController::class);
    Route::get('country', [CountryController::class, 'get_all_country'])->name('country');
    ////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////////////////////////////////////////////////////////
    Route::resource('/role', RoleController::class);
    Route::resource('/user_role', UserRoleController::class);
    Route::get('/save_user_role', [UserRoleController::class, 'save_user_role'])->name('save_user_role');
    Route::resource('/role_perm', RolePermissionController::class);
    Route::get('/save_role_perm', [RolePermissionController::class, 'save_role_perm'])->name('save_role_perm');





    /***************************************************************************/


    Route::GET('tractors', function () {
        return view('tractorIndex');
    });
    Route::GET('tractorsdata', [TractorsController::class, 'indexWithRequest'])->name('tractorsdata');
    // Route::POST('tractorStore', [TractorsController::class, 'store'])->name('tractorStore');
    Route::Resource('tractor', TractorsController::class);
    Route::get('gearbox', [GearboxController::class, 'get_all_gearbox'])->name('gearbox');

    Route::get('get_all_drive', [DriveController::class, 'get_all_drive'])->name('get_all_drive');
    Route::get('storedrp', [StoreController::class, 'get_all_store'])->name('storedrp');

    Route::GET('tractorspecs', [TractorsController::class, 'tractorspecs'])->name('tractorspecs');
    Route::GET('tractorBrand', [TractorsController::class, 'tractorBrand'])->name('tractorBrand');
    Route::GET('tractormodel/{Bid}/{ttypeid}', [TractorsController::class, 'tractormodel'])->name('tractormodel');
    Route::GET('tractorseries/{Mid}', [TractorsController::class, 'tractorseries'])->name('tractorseries');
    Route::GET('tractorprint/{Tid}', [TractorsController::class, 'printtractor'])->name('tractor.print');
    Route::GET('gearindexdata', [GearboxController::class, 'indexdata'])->name('gearindexdata');
    Route::GET('tractorIdData/{tractorId}', [TractorsController::class, 'indexWithID'])->name('tractorIdData');

    Route::GET('clarks', function () {
        return view('clarkIndex');
    });
    Route::GET('clarksdata', [ClarksController::class, 'indexWithRequest'])->name('clarksdata');
    Route::Resource('clark', ClarksController::class);
    Route::GET('clarkspecs', [ClarksController::class, 'clarkspecs'])->name('clarkspecs');
    Route::GET('clarkBrand', [ClarksController::class, 'clarkBrand'])->name('clarkBrand');
    Route::GET('clarkmodel/{Bid}/{ttypeid}', [ClarksController::class, 'clarkmodel'])->name('clarkmodel');
    Route::GET('clarkseries/{Mid}', [ClarksController::class, 'clarkseries'])->name('clarkseries');
    Route::GET('clarkprint/{Tid}', [ClarksController::class, 'printclark'])->name('clark.print');
    Route::GET('clarkIdData/{clarkId}', [ClarksController::class, 'indexWithID'])->name('clarkIdData');

    Route::GET('equips', function () {
        return view('equipIndex');
    });
    Route::GET('equipsdata', [EquipsController::class, 'indexWithRequest'])->name('equipsdata');
    Route::Resource('equip', EquipsController::class);
    Route::GET('equipspecs', [EquipsController::class, 'equipspecs'])->name('equipspecs');
    Route::GET('equipBrand', [EquipsController::class, 'equipBrand'])->name('equipBrand');
    Route::GET('equipmodel/{Bid}/{ttypeid}', [EquipsController::class, 'equipmodel'])->name('equipmodel');
    Route::GET('equipseries/{Mid}', [EquipsController::class, 'equipseries'])->name('equipseries');
    Route::GET('equipprint/{Eid}', [EquipsController::class, 'printequip'])->name('equip.print');
    Route::GET('equipIdData/{equipId}', [EquipsController::class, 'indexWithID'])->name('equipIdData');


    Route::GET('partNumbers', function () {
        return view('partNumbers');
    });
    Route::GET('partNumberData', [PartNumberController::class, 'partNumberIndex'])->name('partNumberData');
    Route::GET('defectsItems', function () {
        return view('defectsItems');
    });
    Route::GET('defectsItemsData', [AllPartsController::class, 'defectsItemsIndex'])->name('defectsItemsData');



     //**************************Adel_start************** */


 Route::resource('/safeMoney', SafeMoneyController::class);
     Route::resource('/banksafeMoney', BankSafeMoneyController::class);
     Route::post('/add_money_bank', [BankSafeMoneyController::class, 'add_money_bank'])->name('add_money_bank');
     Route::post('/add_other_bank', [BankSafeMoneyController::class, 'add_other_bank'])->name('add_other_bank');
     Route::get('/show_safe_bank_Money_month/{day}', [BankSafeMoneyController::class, 'show_safe_bank_Money_month'])->name('show_safe_bank_Money_month');
     Route::post('/money_bank_send_store', [BankSafeMoneyController::class, 'money_bank_send_store'])->name('money_bank_send_store');


     Route::get('/get_safe_store/{id}', [SafeMoneyController::class, 'get_safe_store'])->name('get_safe_store');

     Route::get('/show_safeMoney_month', [SafeMoneyController::class, 'show_safeMoney_month'])->name('show_safeMoney_month');
     Route::post('/money_send_store', [SafeMoneyController::class, 'money_send_store'])->name('money_send_store');
     Route::post('/money_send_company', [SafeMoneyController::class, 'money_send_company'])->name('money_send_company');
     Route::post('/money_send_bank', [SafeMoneyController::class, 'money_send_bank'])->name('money_send_bank');

     Route::post('/add_money', [SafeMoneyController::class, 'add_money'])->name('add_money');
     Route::post('/add_other', [SafeMoneyController::class, 'add_other'])->name('add_other');
     Route::resource('/employee', EmployeeController::class);
     Route::resource('/employee_salary', EmployeeSalaryController::class);
     Route::get('/get_store_employee_salary/{id}', [EmployeeSalaryController::class, 'get_store_employee_salary'])->name('get_store_employee_salary');

     Route::get('/get_employee_salary', [EmployeeSalaryController::class, 'get_employee_salary'])->name('get_employee_salary');
     Route::get('/get_employee_salary_details', [EmployeeSalaryController::class, 'get_employee_salary_details'])->name('get_employee_salary_details');
     Route::get('/employee_salary_details/{id}', [EmployeeSalaryController::class, 'employee_salary_details'])->name('employee_salary_details');
     Route::post('/pay_salary', [EmployeeSalaryController::class, 'pay_salary'])->name('pay_salary');
     Route::get('/salary_history/{id}', [EmployeeSalaryController::class, 'salary_history'])->name('salary_history');

     Route::resource('/notes', NoteSafeMoneyController::class);


     Route::resource('/solfa', SolfaController::class);
     Route::get('/get_solfa_store/{id}', [SolfaController::class, 'get_solfa_store'])->name('get_solfa_store');

     Route::get('/employee_solfa_details/{id}', [SolfaController::class, 'employee_solfa_details'])->name('employee_solfa_details');
     Route::get('/employee_solfa_history/{id}', [SolfaController::class, 'employee_solfa_history'])->name('employee_solfa_history');
     Route::get('/employee_solfa_history_details/{id}', [SolfaController::class, 'employee_solfa_history_details'])->name('employee_solfa_history_details');
     Route::resource('/bank_type', BankTypeController::class);



    Route::resource('kitsCollection',kitCollectionController::class);
    Route::get('/kitInfo', [kitCollectionController::class, 'kitInfo'])->name('kitInfo');

    Route::POST('/save_kit_collection', [kitCollectionController::class, 'save_kit_collection'])->name('save_kit_collection');

          //**************************Adel_end************** */
          
    /************************ Acountant ///////////////////////////////// */
    Route::resource('branch', BranchController::class);
    Route::GET('/calcTree/{id}',[BranchController::class,'calcTree']);
    Route::get('/getallbranch',[BranchController::class ,'getAll'])->name('profile');;
    Route::post('/save_branch',[BranchController::class,'save_branch']);
    Route::get('/delete_branch',[BranchController::class,'delete_branch']);
    Route::get('/branchtable',[BranchController::class,'getAllwithView']);
    Route::get('/branch_table',[BranchController::class,'getparent']);

    Route::get('/branch_child/{id}',[BranchController::class,'getbranchwithchild']);
    Route::resource('qaydtype', QaydTypeController::class);
    Route::get('/getqaydtype',[QaydTypeController::class,'getAll']);

    Route::get('/getallfinalchild',[BranchController::class,'getAllFinalChild']);
    Route::get('account/search',[QaydController::class,'search']);
    Route::get('qayd/search',[QaydController::class,'search']);
    Route::get('qayd/searchaccount',[QaydController::class,'searchaccount']);
    Route::get('qayd/trialbalance',[QaydController::class,'trialbalance']);
    Route::get('gettrialbalance',[QaydController::class,'gettrialbalance']);
    Route::resource('qayd', QaydController::class);
    Route::post('getallAccount',[QaydController::class,'getallAccount']);
    Route::post('accountstatement',[QaydController::class,'accountstatement']);

    Route::get('test',[QaydController::class,'test']);
    Route::get('testt/{id}',[BranchController::class,'calcTree']);
    Route::get('calcTree/{id}',[BranchController::class,'calcTree']);
    //////////////////////////////////////////////////////////////////////

});

require __DIR__ . '/auth.php';
